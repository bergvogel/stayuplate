<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce, $wp_query, $wp;

$curr_style = get_option( 'wc_settings_prdctfltr_style_preset', 'pf_default' );

$catalog_orderby = apply_filters( 'prdctfltr_catalog_orderby', array(
	'' => __( 'None', 'prdctfltr' ),
	'menu_order' => __( 'Default', 'prdctfltr' ),
	'popularity' => __( 'Popularity', 'prdctfltr' ),
	'rating'     => __( 'Average rating', 'prdctfltr' ),
	'date'       => __( 'Newness', 'prdctfltr' ),
	'price'      => __( 'Price: low to high', 'prdctfltr' ),
	'price-desc' => __( 'Price: high to low', 'prdctfltr' )
) );

?>
<div id="prdctfltr_woocommerce" class="prdctfltr_woocommerce<?php echo ( $curr_style !== 'pf_disable' ? ' ' . $curr_style : '' ); ?>">

<a id="prdctfltr_woocommerce_filter" href="#"><i class="prdctfltr-bars"></i></a>
<span>
<?php _e('Filter products', 'prdctfltr'); ?>
<?php echo ( isset($_GET['orderby'] ) ? ' / <span>'.$catalog_orderby[$_GET['orderby']] . '</span> <a href="#" data-key="prdctfltr_orderby"><i class="prdctfltr-delete"></i></a>' : '' );?>
<?php echo ( isset($_GET['min_price']) ? ' / <span>' . $_GET['min_price'].( isset($_GET['max_price']) && $_GET['max_price'] !== '9999999999' ? ' - '.$_GET['max_price'] . '</span>' : ' +</span>' ) . ' ' . get_woocommerce_currency_symbol() . ' <a href="#" data-key="prdctfltr_byprice"><i class="prdctfltr-delete"></i></a>' : '' ); ?>
<?php
	if ( isset($_GET['product_cat']) ) {
		$curr_term = get_term_by('slug', $_GET['product_cat'], 'product_cat');
		echo ' / <span>' . $curr_term->name . '</span> <a href="#" data-key="prdctfltr_cat"><i class="prdctfltr-delete"></i></a>';
	}
?>
<?php
	if ( isset($_GET['product_tag']) ) {
		$curr_term = get_term_by('slug', $_GET['product_tag'], 'product_tag');
		echo ' / <span>' . $curr_term->name . '</span> <a href="#" data-key="prdctfltr_tag"><i class="prdctfltr-delete"></i></a>';
	}
?>
<?php
	if ( isset($_GET['characteristics']) ) {
		$curr_term = get_term_by('slug', $_GET['characteristics'], 'characteristics');
		echo ' / <span>' . $curr_term->name . '</span> <a href="#" data-key="prdctfltr_characteristics"><i class="prdctfltr-delete"></i></a>';
	}
?>
<?php
	if ( $attribute_taxonomies = wc_get_attribute_taxonomies() ) {
		$curr_attr = array();
		$n = 0;

		foreach ( $attribute_taxonomies as $tax ) {
			$n++;
			if ( isset($_GET['pa_' . $tax->attribute_name]) ) {
				$curr_term = get_term_by('slug', $_GET['pa_' . $tax->attribute_name], 'pa_' . $tax->attribute_name);
				echo ' / <span>' . $tax->attribute_label . ' - ' . $curr_term->name . '</span> <a href="#" data-key="prdctfltr_attributes_'.$n.'"><i class="prdctfltr-delete"></i></a>';
			}
		}
	}
?>
 / 
	<?php



			$curr_args = array(
				'post_type'				=> 'product',
				'post_status' 			=> 'publish',
				'ignore_sticky_posts'	=> 1,
			);


			if ( isset($_GET['orderby']) ) {
				$curr_args = array_merge( $curr_args, array(
							'orderby' => $_GET['orderby']
					) );
				if ( $_GET['orderby'] == 'rating' ) {
					$curr_args = array_merge( $curr_args, array(
								'order' => 'DESC'
						) );
				}
			}

			if ( isset($_GET['min_price']) ) {
				if ( isset($_GET['max_price']) ) {
					$curr_args = array_merge( $curr_args, array(
								'meta_key' => '_price',
								'meta_value' => array(floatval($_GET['min_price']), floatval($_GET['max_price'])),
								'meta_type' => 'numeric',
								'meta_compare' => 'BETWEEN'
						) );
				}
				else {
					$curr_args = array_merge( $curr_args, array(
								'meta_key' => '_price',
								'meta_value' => array(floatval($_GET['min_price']), 999999999),
								'meta_type' => 'numeric',
								'meta_compare' => 'BETWEEN'
						) );
				}

			}

			if ( isset($_GET['product_cat']) ) {
				$curr_args = array_merge( $curr_args, array(
							'product_cat' => $_GET['product_cat']
					) );

			}

			if ( isset($_GET['product_tag']) ) {
				$curr_args = array_merge( $curr_args, array(
							'product_tag' => $_GET['product_tag']
					) );

			}

			if ( isset($_GET['characteristics']) ) {
				$curr_args = array_merge( $curr_args, array(
							'characteristics' => $_GET['characteristics']
					) );

			}

			if ( isset($_GET['sale_products']) ) {
				$curr_args = array_merge( $curr_args, array(
						'meta_query' => array(
							'key' => '_sale_price',
							'value' => 0,
							'compare' => '>',
							'type' => 'numeric'
						)
					)
				);
			}

			foreach($_GET as $k => $v){
				if (strpos($k,'pa_') !== false) {
					$curr_args = $curr_args + array(
						'tax_query' 			=> array(
							array(
								'taxonomy' 		=> $k,
								'terms' 		=> $v,
								'field' 		=> 'slug',
								'operator' 		=> 'IN'
							)
						)
					);
				}
			}

			$products = new WP_Query( $curr_args );



	$paged    = max( 1, $products->get( 'paged' ) );
	$per_page = $products->get( 'posts_per_page' );
	$total    = $products->found_posts;
	$first    = ( $per_page * $paged ) - $per_page + 1;
	$last     = min( $total, $products->get( 'posts_per_page' ) * $paged );

	if ( $total == 0 ) {
		_e('No products found but you might like these&hellip;', 'prdctfltr');
	} elseif ( $total == 1 ) {
		_e( 'Showing the single result', 'prdctfltr' );
	} elseif ( $total <= $per_page || -1 == $per_page ) {
		printf( __( 'Showing all %d results', 'prdctfltr' ), $total );
	} else {
		printf( _x( 'Showing %1$d - %2$d of %3$d results', '%1$d = first, %2$d = last, %3$d = total', 'prdctfltr' ), $first, $last, $total );
	}

	?>
</span>
<?php
	$curr_action = get_permalink( woocommerce_get_page_id( 'shop' ) );
	if ( $curr_action == home_url('/') && !is_page() ) {
		$post = get_post(woocommerce_get_page_id( 'shop' ));
		$curr_action = get_permalink( woocommerce_get_page_id( 'shop' ) ) . $post->post_name;
	}
	else {
		if ( get_option( 'permalink_structure' ) == '' )
			$curr_action = remove_query_arg( array( 'page', 'paged' ), add_query_arg( $wp->query_string, '', home_url( $wp->request ) ) );
		else
			$curr_action = preg_replace( '%\/page/[0-9]+%', '', home_url( $wp->request ) );
	}

	$curr_elements = get_option( 'wc_settings_prdctfltr_selected', array('sort','price','cat') );
	$curr_attrs = get_option( 'wc_settings_prdctfltr_attributes', array() );
?>
<form action="<?php echo $curr_action; ?>" class="prdctfltr_woocommerce_ordering<?php echo ( ( strpos( $curr_style, 'inline' ) !== true ) ? ' prdctfltr_columns_' . (count($curr_elements)+count($curr_attrs)) : '')?>" method="get">

	<?php
		foreach ( $curr_elements as $k => $v ) :
		
			switch ( $v ) :

			case 'sort' : ?>

				<div class="prdctfltr_orderby">
				<input name="orderby" type="hidden"<?php echo ( isset($_GET['orderby'] ) ? ' value="'.$_GET['orderby'].'"' : '' );?>>
				<span><?php _e('Sort by', 'prdctfltr'); ?></span>
				<?php
					if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' )
						unset( $catalog_orderby['rating'] );

					foreach ( $catalog_orderby as $id => $name ) {
						printf('<label%4$s><input type="checkbox" value="%1$s" %2$s /><span>%3$s</span></label>', esc_attr( $id ), ( isset($_GET['orderby']) && $_GET['orderby'] == $id ? 'checked' : '' ), esc_attr( $name ), ( isset($_GET['orderby']) && $_GET['orderby'] == $id ? ' class="prdctfltr_active"' : '' ) );
					}
				?>
				</div>

			<?php break;

			case 'price' :
			 ?>

				<div class="prdctfltr_byprice">
				<input name="min_price" type="hidden"<?php echo ( isset($_GET['min_price'] ) ? ' value="'.$_GET['min_price'].'"' : '' );?>>
				<input name="max_price" type="hidden"<?php echo ( isset($_GET['max_price'] ) ? ' value="'.$_GET['max_price'].'"' : '' );?>>
				<span><?php _e('Price range', 'prdctfltr'); ?></span>
				<?php
					$curr_price = ( isset($_GET['min_price']) ? $_GET['min_price'].'-'.( isset($_GET['max_price']) ? $_GET['max_price'] : '' ) : '' );
					
					$curr_price_set = get_option( 'wc_settings_prdctfltr_price_range', 100 );

					$curr_prices= array();
					
					for ($i = 1; $i <= 6; $i++) {
						$curr_prices[$i] = (($curr_price_set*$i)-$curr_price_set).'-'.( $i !== 6 ? ($curr_price_set*$i) : '' );
					}

					$catalog_price = apply_filters( 'prdctfltr_catalog_price', array(
						'-' => __( 'None', 'prdctfltr' ),
						$curr_prices[1] => str_replace('-',' - ',$curr_prices[1]),
						$curr_prices[2] => str_replace('-',' - ',$curr_prices[2]),
						$curr_prices[3] => str_replace('-',' - ',$curr_prices[3]),
						$curr_prices[4] => str_replace('-',' - ',$curr_prices[4]),
						$curr_prices[5] => str_replace('-',' - ',$curr_prices[5]),
						$curr_prices[6] => str_replace('-',' - +',$curr_prices[6])
					) );

					foreach ( $catalog_price as $id => $name ) {
						printf('<label%5$s><input type="checkbox" value="%1$s" %2$s /><span>%3$s %4$s</span></label>', esc_attr( $id ), ( $curr_price == $id ? 'checked' : '' ), esc_attr( $name ), ( $id !== '-' ? get_woocommerce_currency_symbol() : '' ), ( $curr_price == $id ? ' class="prdctfltr_active"' : '' ) );
					}
				?>
				</div>

			<?php break;

			case 'cat' : ?>

				<?php
					$curr_limit = get_option( 'wc_settings_prdctfltr_cat_limit', 0 );
					if ( $curr_limit !== 0 ) {
						$catalog_categories = get_terms( 'product_cat', array('hide_empty' => 1, 'orderby' => 'count', 'number' => $curr_limit ) );
					}
					else {
						$catalog_categories = get_terms( 'product_cat', array('hide_empty' => 1 ) );
					}

					if ( !empty( $catalog_categories ) && !is_wp_error( $catalog_categories ) ){
				?>
				<div class="prdctfltr_cat">
				<input name="product_cat" type="hidden"<?php echo ( isset($_GET['product_cat'] ) ? ' value="'.$_GET['product_cat'].'"' : '' );?>>
				<span><?php _e('Categories', 'prdctfltr'); ?></span>
				<?php
					printf('<label><input type="checkbox" value="" /><span>%1$s</span></label>', __('None' , 'prdctfltr') );
					foreach ( $catalog_categories as $term ) {
						printf('<label%4$s><input type="checkbox" value="%1$s" %3$s /><span>%2$s</span></label>', $term->slug, $term->name, ( isset($_GET['product_cat']) && $_GET['product_cat'] == $term->slug ? 'checked' : '' ), ( isset($_GET['product_cat']) && $_GET['product_cat'] == $term->slug ? ' class="prdctfltr_active"' : '' ) );
					}
				?>
				</div>
				<?php
				}
				?>

			<?php break;

			case 'tag' : ?>

				<?php
					$curr_limit = get_option( 'wc_settings_prdctfltr_tag_limit', 0 );
					if ( $curr_limit !== 0 ) {
						$catalog_tags = get_terms( 'product_tag', array('hide_empty' => 1, 'orderby' => 'count', 'number' => $curr_limit ) );
					}
					else {
						$catalog_tags = get_terms( 'product_tag', array('hide_empty' => 1 ) );
					}

					if ( !empty( $catalog_tags ) && !is_wp_error( $catalog_tags ) ){
				?>
				<div class="prdctfltr_tag">
				<input name="product_tag" type="hidden"<?php echo ( isset($_GET['product_tag'] ) ? ' value="'.$_GET['product_tag'].'"' : '' );?>>
				<span><?php _e('Tags', 'prdctfltr'); ?></span>
				<?php
					printf('<label><input type="checkbox" value="" /><span>%1$s</span></label>', __('None' , 'prdctfltr') );
					foreach ( $catalog_tags as $term ) {
						printf('<label%4$s><input type="checkbox" value="%1$s" %3$s /><span>%2$s</span></label>', $term->slug, $term->name, ( isset($_GET['product_tag']) && $_GET['product_tag'] == $term->slug ? 'checked' : '' ), ( isset($_GET['product_tag']) && $_GET['product_tag'] == $term->slug ? ' class="prdctfltr_active"' : '' ) );
					}
				?>
				</div>
				<?php
				}
				?>

			<?php break;

			case 'char' : ?>

				<?php
					$curr_limit = get_option( 'wc_settings_prdctfltr_custom_tax_limit', 0 );
					if ( $curr_limit !== 0 ) {
						$catalog_characteristics = get_terms( 'characteristics', array('hide_empty' => 1, 'orderby' => 'count', 'number' => $curr_limit ) );
					}
					else {
						$catalog_characteristics = get_terms( 'characteristics', array('hide_empty' => 1 ) );
					}

					if ( !empty( $catalog_characteristics ) && !is_wp_error( $catalog_characteristics ) ){
				?>
				<div class="prdctfltr_characteristics">
				<input name="characteristics" type="hidden"<?php echo ( isset($_GET['characteristics'] ) ? ' value="'.$_GET['characteristics'].'"' : '' );?>>
				<span><?php _e('Characteristics', 'prdctfltr'); ?></span>
				<?php
					printf('<label><input type="checkbox" value="" /><span>%1$s</span></label>', __('None' , 'prdctfltr') );
					foreach ( $catalog_characteristics as $term ) {
						printf('<label%4$s><input type="checkbox" value="%1$s" %3$s /><span>%2$s</span></label>', $term->slug, $term->name, ( isset($_GET['characteristics']) && $_GET['characteristics'] == $term->slug ? 'checked' : '' ), ( isset($_GET['characteristics']) && $_GET['characteristics'] == $term->slug ? ' class="prdctfltr_active"' : '' ) );
					}
				?>
				</div>
				<?php
				}
				?>

			<?php break;

			default :
			break;

			endswitch;
		
		endforeach;

		$n = 0;
		foreach ( $curr_attrs as $k => $attr ) :

			$n++;

			$curr_attributes = get_terms( $attr );
			
			$curr_term = get_taxonomy( $attr );
	?>
				<div class="prdctfltr_attributes prdctfltr_attributes_<?php echo $n; ?>">
				<input name="<?php echo $attr; ?>" type="hidden"<?php echo ( isset($_GET[$attr] ) ? ' value="'.$_GET[$attr].'"' : '' );?>>
				<span><?php echo $curr_term->label; ?></span>
				<?php
					printf('<label><input type="checkbox" value="" /><span>%1$s</span></label>', __('None' , 'prdctfltr') );
					foreach ( $curr_attributes as $attribute ) {
						printf('<label%4$s><input type="checkbox" value="%1$s" %3$s /><span>%2$s</span></label>', $attribute->slug, $attribute->name, ( isset($_GET[$attr]) && $_GET[$attr] == $attribute->slug ? 'checked' : '' ), ( isset($_GET[$attr]) && $_GET[$attr] == $attribute->slug ? ' class="prdctfltr_active"' : '' ) );
					}
				?>
				</div>
				<?php
		endforeach;
	?>
	<div class="prdctfltr_clear"></div>
	<a id="prdctfltr_woocommerce_filter_submit" class="button" href="#"><?php _e('Filter selected', 'prdctfltr'); ?></a>
	<span class="prdctfltr_sale">
		<?php
		printf('<label%2$s><input name="sale_products" type="checkbox"%3$s/><span>%1$s</span></label>', __('Show only products on sale' , 'prdctfltr'), ( isset($_GET['sale_products']) ? ' class="prdctfltr_active"' : '' ), ( isset($_GET['sale_products']) ? ' checked' : '' ) );
		?>
	</span>
	
</form>
</div>
<?php
	if ( $total == 0 ) {
		echo do_shortcode('[prdctfltr_sc_products no_products="yes"]');
	}
?>