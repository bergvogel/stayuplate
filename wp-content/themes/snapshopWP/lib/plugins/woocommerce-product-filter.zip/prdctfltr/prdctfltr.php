<?php
/*
Plugin Name: WooCommerce Product Filter
Plugin URI: http://www.mihajlovicnenad.com/product-filter
Description: Advanced product filter for any Wordpress template! - mihajlovicnenad.com
Author: Mihajlovic Nenad
Version: 1.2.4
Author URI: http://www.mihajlovicnenad.com
*/

/**
 * Check if WooCommerce is installed
 */
define( "PRDCTFLTR_MULTISITE", ( is_multisite() ? true : false ) );
$using_woo = false;
if ( PRDCTFLTR_MULTISITE === true ) {
	if ( array_key_exists( 'woocommerce/woocommerce.php', maybe_unserialize( get_site_option( 'active_sitewide_plugins') ) ) ) {
		$using_woo = true;
	}
	elseif ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ? 'active' : '' ) {
		$using_woo = true;
	}
}
elseif ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ? 'active' : '' ) {
	$using_woo = true;
}
define( "PRDCTFLTR_WOOCOMMERCE", $using_woo );

if ( $using_woo === false )
	return;

/**
 * Product Filter Translation
 */
load_plugin_textdomain( 'prdctfltr', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );


/**
 * Product Filter Action
 */
function prdctfltr_get_filter() {

	ob_start();

	wc_get_template( 'loop/orderby.php');

	$out = ob_get_clean();
	
	echo $out;
}
add_action('prdctfltr_output', 'prdctfltr_get_filter', 10);

/**
 * Product Filter Basic
 */
$curr_path = dirname( __FILE__ );
$curr_name = basename( $curr_path );
$curr_url = plugins_url( "/$curr_name/" );

define('PRDCTFLTR_URL', $curr_url);
function prdctfltr_path() {
	return untrailingslashit( plugin_dir_path( __FILE__ ) );
}

/*
 * Product Filter Load Scripts
*/
if ( !function_exists('prdctfltr_scripts') ) :
function prdctfltr_scripts() {
	$curr_style = get_option( 'wc_settings_prdctfltr_style_preset', 'pf_default' );
	if ( $curr_style !== 'pf_disable' ) {
		wp_enqueue_style( 'prdctfltr-main-css', PRDCTFLTR_URL .'lib/prdctfltr.css');
	}
	wp_enqueue_style( 'prdctfltr-font-css', PRDCTFLTR_URL .'lib/font/styles.css');
	wp_enqueue_script( 'prdctfltr-main-js', PRDCTFLTR_URL .'lib/prdctfltr_main.js', array( 'jquery' ), '1.0', true);
}
endif;
add_action( 'wp_enqueue_scripts', 'prdctfltr_scripts' );

/*
 * Product Filter Pre Get Posts
*/
if ( !function_exists( 'prdctfltr_wc_meta_query' ) ) :
function prdctfltr_wc_meta_query($query) {

		if ( ! is_admin() && $query->is_main_query() && !is_page() ) {
			$curr_args = array();

			if ( isset($_GET['orderby']) && $_GET['orderby'] !== '' ) {
				$curr_args = array_merge( $curr_args, array(
							'orderby' => $_GET['orderby']
					) );
				if ( $_GET['orderby'] == 'rating' ) {
					$curr_args = array_merge( $curr_args, array(
								'order' => 'DESC'
						) );
				}
			}


			if ( isset($_GET['product_cat']) && $_GET['product_cat'] !== '' ) {
				$curr_args = array_merge( $curr_args, array(
							'product_cat' => $_GET['product_cat']
					) );

			}

			if ( isset($_GET['product_tag']) && $_GET['product_tag'] !== '' ) {
				$curr_args = array_merge( $curr_args, array(
							'product_tag' => $_GET['product_tag']
					) );

			}

			if ( isset($_GET['characteristics']) && $_GET['characteristics'] !== '' ) {
				$curr_args = array_merge( $curr_args, array(
							'characteristics' => $_GET['characteristics']
					) );

			}

			if ( isset($_GET['min_price']) && $_GET['min_price'] !== '' && !isset($_GET['sale_products']) ) {
					global $wpdb;
					$min = floor( $wpdb->get_var(
						$wpdb->prepare('
							SELECT min(meta_value + 0)
							FROM %1$s
							LEFT JOIN %2$s ON %1$s.ID = %2$s.post_id
							WHERE ( meta_key = \'%3$s\' OR meta_key = \'%4$s\' )
							AND meta_value != ""
							', $wpdb->posts, $wpdb->postmeta, '_price', '_min_variation_price' )
						)
					);

				if ( isset($_GET['max_price']) ) {
					$curr_args = array_merge( $curr_args, array(
								'meta_key' => '_price',
								'meta_value' => array( ( floatval($_GET['min_price']) == 0 ? $min : floatval($_GET['min_price']) ), floatval($_GET['max_price'])),
								'meta_type' => 'numeric',
								'meta_compare' => 'BETWEEN'
						) );
				}
				else {
					$max = ceil( $wpdb->get_var(
						$wpdb->prepare('
							SELECT max(meta_value + 0)
							FROM %1$s
							LEFT JOIN %2$s ON %1$s.ID = %2$s.post_id
							WHERE meta_key = \'%3$s\'
						', $wpdb->posts, $wpdb->postmeta, '_price' )
					) );
					$curr_args = array_merge( $curr_args, array(
								'meta_key' => '_price',
								'meta_value' => array(( floatval($_GET['min_price']) == 0 ? $min : floatval($_GET['min_price']) ), $max),
								'meta_type' => 'numeric',
								'meta_compare' => 'BETWEEN'
						) );
				}

			}

			foreach( $_GET as $k => $v ){
				if ( strpos($k,'pa_') !== false && $v !== '' ) {
					$curr_args = $curr_args + array(
						'tax_query' 			=> array(
							array(
								'taxonomy' 		=> $k,
								'terms' 		=> $v,
								'field' 		=> 'slug',
								'operator' 		=> 'IN'
							)
						)
					);
				}
			}

			if ( isset($_GET['sale_products']) && $_GET['sale_products'] !== '' ) {
				add_filter( 'posts_join' , 'prdctfltr_join_posts');
				add_filter( 'posts_where' , 'prdctfltr_sale_filter' );
			}

		foreach ( $curr_args as $k => $v ) {
			$query->set($k,$v);
		}

}

}
endif;
add_filter('pre_get_posts','prdctfltr_wc_meta_query');

/*
 * Product Filter Sale Filter
*/
function prdctfltr_sale_filter ( $where ) {
	global $wpdb;

	$where = str_replace("AND ( (wp_postmeta.meta_key = '_visibility' AND CAST(wp_postmeta.meta_value AS CHAR) IN ('visible','catalog')) )", "", $where);

	if ( isset($_GET['min_price'] ) ) {
		
		if ( $_GET['min_price'] == 0 ) {
			global $wpdb;
			$min = floor( $wpdb->get_var(
				$wpdb->prepare('
					SELECT min(meta_value + 0)
					FROM %1$s
					LEFT JOIN %2$s ON %1$s.ID = %2$s.post_id
					WHERE ( meta_key = \'%3$s\' OR meta_key = \'%4$s\' )
					AND meta_value != ""
					', $wpdb->posts, $wpdb->postmeta, '_price', '_min_variation_price' )
				)
			);
		}
		else {
			$min = $_GET['min_price'];
		}

		if ( isset($_GET['max_price']) ) {
			$max = $_GET['max_price'];
		}
		else {
			$max = ceil( $wpdb->get_var(
				$wpdb->prepare('
					SELECT max(meta_value + 0)
					FROM %1$s
					LEFT JOIN %2$s ON %1$s.ID = %2$s.post_id
					WHERE meta_key = \'%3$s\'
				', $wpdb->posts, $wpdb->postmeta, '_price' )
			) );
		}
			$where .= " AND ( ( ($wpdb->postmeta.meta_key LIKE '_sale_price' AND $wpdb->postmeta.meta_value > $min ) AND ($wpdb->postmeta.meta_key LIKE '_sale_price' AND $wpdb->postmeta.meta_value < $max ) ) OR ( ($wpdb->postmeta.meta_key LIKE '_min_variation_sale_price' AND $wpdb->postmeta.meta_value > $min ) AND ($wpdb->postmeta.meta_key LIKE '_min_variation_sale_price' AND $wpdb->postmeta.meta_value < $max ) ) ) ";
	}
	else {
		$where .= " AND ( ( ($wpdb->postmeta.meta_key LIKE '_sale_price' AND $wpdb->postmeta.meta_value > 0 ) OR ($wpdb->postmeta.meta_key LIKE '_min_variation_sale_price' AND $wpdb->postmeta.meta_value > 0 ) )  ) ";
	}

	remove_filter( 'posts_join' , 'prdctfltr_join_posts');
	remove_filter( 'posts_where' , 'prdctfltr_sale_filter' );

	return $where;
	
	}

/*
 * Product Filter Join Tables
*/
function prdctfltr_join_posts($join){
	global $wpdb;
	$join .= " LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id ";
	return $join;
}

/*
 * Product Filter Register Characteristics
*/
$curr_char = get_option( 'wc_settings_prdctfltr_custom_tax', 'no' );
if ( $curr_char == 'yes' ) {
	function prdctfltr_characteristics() {

		$labels = array(
			'name'                       => _x( 'Characteristics', 'taxonomy general name', 'prdctfltr' ),
			'singular_name'              => _x( 'Characteristics', 'taxonomy singular name', 'prdctfltr' ),
			'search_items'               => __( 'Search Characteristics', 'prdctfltr' ),
			'popular_items'              => __( 'Popular Characteristics', 'prdctfltr' ),
			'all_items'                  => __( 'All Characteristics', 'prdctfltr' ),
			'parent_item'                => null,
			'parent_item_colon'          => null,
			'edit_item'                  => __( 'Edit Characteristics', 'prdctfltr' ),
			'update_item'                => __( 'Update Characteristics', 'prdctfltr' ),
			'add_new_item'               => __( 'Add New Characteristic', 'prdctfltr' ),
			'new_item_name'              => __( 'New Characteristic Name', 'prdctfltr' ),
			'separate_items_with_commas' => __( 'Separate Characteristics with commas', 'prdctfltr' ),
			'add_or_remove_items'        => __( 'Add or remove characteristics', 'prdctfltr' ),
			'choose_from_most_used'      => __( 'Choose from the most used characteristics', 'prdctfltr' ),
			'not_found'                  => __( 'No characteristics found.', 'prdctfltr' ),
			'menu_name'                  => __( 'Characteristics', 'prdctfltr' ),
		);

		$args = array(
			'hierarchical'          => false,
			'labels'                => $labels,
			'show_ui'               => true,
			'show_admin_column'     => true,
			'update_count_callback' => '_update_post_term_count',
			'query_var'             => true,
			'rewrite'               => array( 'slug' => 'characteristics' ),
		);

		register_taxonomy( 'characteristics', array('product'), $args );
	}
	add_action( 'init', 'prdctfltr_characteristics', 0 );
}

$curr_disable = get_option( 'wc_settings_prdctfltr_enable', 'yes' );

if ( $curr_disable == 'yes') {

	/*
	 * Product Filter Override WooCommerce Template
	*/
	function prdctrfltr_add_filter ( $template, $slug, $name ) {

		if ( $name ) {
			$path = plugin_dir_path( __FILE__ ) . WC()->template_path() . "{$slug}-{$name}.php";
		} else {
			$path = plugin_dir_path( __FILE__ ) . WC()->template_path() . "{$slug}.php";
		}

		return file_exists( $path ) ? $path : $template;

	}
	add_filter( 'wc_get_template_part', 'prdctrfltr_add_filter', 10, 3 );

	function prdctrfltr_add_loop_filter ( $template, $template_name, $template_path ) {

		$path = plugin_dir_path( __FILE__ ) . $template_path . $template_name;
		return file_exists( $path ) ? $path : $template;

	}
	add_filter( 'woocommerce_locate_template', 'prdctrfltr_add_loop_filter', 10, 3 );


	/*
	 * Product Filter Search Variable Products
	*/
	function search_array($array, $attrs) {
		$results = array();

		foreach ($array as $subarray) {

			if ( isset($subarray['attributes'])) {
				if ( in_array($attrs, $subarray['attributes']) ) {
					$results[] = $subarray;
				}
				else {
					foreach ( $attrs as $k => $v ) {
						if (in_array($v, $subarray['attributes'])) {
							$results[] = $subarray;
						}
					}
				}
			}
		}

		return $results;
	}

}

/*
 * Product Filter Get Variable Product
*/
if ( function_exists('runkit_function_rename') && function_exists( 'woocommerce_get_product_thumbnail' ) ) :
	runkit_function_rename ( 'woocommerce_get_product_thumbnail', 'old_woocommerce_get_product_thumbnail' );
endif;
if ( !function_exists( 'woocommerce_get_product_thumbnail' ) ) :
function woocommerce_get_product_thumbnail( $size = 'shop_catalog', $placeholder_width = 0, $placeholder_height = 0  ) {
	global $post;

	$product = get_product($post->ID);

	$attrs = array();
	foreach($_GET as $k => $v){
		if (strpos($k,'pa_') !== false) {
			$attrs = $attrs + array(
				$k => $v
			);
		}
	}

	if ( count($attrs) > 0 ) {

		if ( $product->is_type( 'variable' ) ) {

			$curr_var = $product->get_available_variations();
			$si = search_array($curr_var, $attrs);

		}
	}

	if ( isset($si[0]) && $si[0]['variation_id'] && has_post_thumbnail( $si[0]['variation_id'] ) ) {
		$image = get_the_post_thumbnail( $si[0]['variation_id'], $size );
	} elseif ( has_post_thumbnail( $product->id ) ) {
		$image = get_the_post_thumbnail( $product->id, $size );
	} elseif ( ( $parent_id = wp_get_post_parent_id( $product->id ) ) && has_post_thumbnail( $parent_id ) ) {
		$image = get_the_post_thumbnail( $product, $size );
	} else {
		$image = wc_placeholder_img( $size );
	}

	return $image;

}
endif;

/*
 * Product Filter Settings Class
*/
class WC_Settings_Prdctfltr {

	public static function init() {
		add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::prdctfltr_add_settings_tab', 50 );
		add_action( 'woocommerce_settings_tabs_settings_products_filter', __CLASS__ . '::prdctfltr_settings_tab' );
		add_action( 'woocommerce_update_options_settings_products_filter', __CLASS__ . '::prdctfltr_update_settings' );
	}

	public static function prdctfltr_add_settings_tab( $settings_tabs ) {
		$settings_tabs['settings_products_filter'] = __( 'Product Filter', 'prdctfltr' );
		return $settings_tabs;
	}

	public static function prdctfltr_settings_tab() {
		woocommerce_admin_fields( self::prdctfltr_get_settings() );
	}

	public static function prdctfltr_update_settings() {
		woocommerce_update_options( self::prdctfltr_get_settings() );
	}

	public static function prdctfltr_get_settings() {

		if ( $attribute_taxonomies = wc_get_attribute_taxonomies() ) {
			$curr_attr = array();
			foreach ( $attribute_taxonomies as $tax ) {

				$curr_label = ! empty( $tax->attribute_label ) ? $tax->attribute_label : $tax->attribute_name;

				$curr_attr['pa_' . $tax->attribute_name] = $curr_label;

			}
		}

		$settings = array(
			'section_enable_title' => array(
				'name'     => __( 'Enable/Disable Shop Filter', 'prdctfltr' ),
				'type'     => 'title',
				'desc'     => __( 'Disable Product Filter WooCommerce template.', 'prdctfltr' ),
				'id'       => 'wc_settings_prdctfltr_enable_title'
			),
			'prdctfltr_enable' => array(
				'name' => __( 'Enable/Disable', 'prdctfltr' ),
				'type' => 'checkbox',
				'desc' => __( 'Uncheck this option in order to disable Product Filter template override on Shop page.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_enable',
				'default' => 'yes',
			),
			'section_enable_end' => array(
				'type' => 'sectionend',
				'id' => 'wc_settings_prdctfltr_enable_end'
			),
			'section_title' => array(
				'name'     => __( 'Select Product Filters', 'prdctfltr' ),
				'type'     => 'title',
				'desc'     => __( 'Select product filters to use.', 'prdctfltr' ),
				'id'       => 'wc_settings_prdctfltr_section_title'
			),
			'prdctfltr_selected' => array(
				'name' => __( 'Select Filters', 'prdctfltr' ),
				'type' => 'multiselect',
				'desc' => __( 'Select filters. Use CTRL+Click to select multiple filters.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_selected',
				'options' => array(
					'sort' => __('Sort By', 'prdctfltr'),
					'price' => __('By Price', 'prdctfltr'),
					'cat' => __('By Categories', 'prdctfltr'),
					'tag' => __('By Tags', 'prdctfltr'),
					'char' => __('By Characteristics', 'prdctfltr')
				),
				'default' => array('sort','price','cat')
			),
			'prdctfltr_attributes' => array(
				'name' => __( 'Select Attributes', 'prdctfltr' ),
				'type' => 'multiselect',
				'desc' => __( 'Select your attributes. Use CTRL+Click to select multiple attributes.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_attributes',
				'options' => $curr_attr,
				'default' => array()
			),
			'section_end' => array(
				'type' => 'sectionend',
				'id' => 'wc_settings_prdctfltr_section_end'
			),
			'section_filter_title' => array(
				'name'     => __( 'Product Filter Settings', 'prdctfltr' ),
				'type'     => 'title',
				'desc'     => __( 'Setup product filters.', 'prdctfltr' ),
				'id'       => 'wc_settings_prdctfltr_filters_title'
			),
			'prdctfltr_price_range' => array(
				'name' => __( 'Price Range Filter', 'prdctfltr' ),
				'type' => 'select',
				'desc' => __( 'Select price range for price filter.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_price_range',
				'options' => array(
					'10' => '0-10',
					'100' => '0-100',
					'1000' => '0-1000',
					'10000' => '0-10000',
					'100000' => '0-100000'
				),
				'default' => '100'
			),
			'prdctfltr_cat_limit' => array(
				'name' => __( 'Limit Categories', 'prdctfltr' ),
				'type' => 'number',
				'desc' => __( 'Limit number of categories to be shown. If limit is set categories with most posts will be shown first.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_cat_limit',
				'default' => 0,
				'custom_attributes' => array(
					'min' 	=> 0,
					'max' 	=> 100,
					'step' 	=> 1
				)
			),
			'prdctfltr_tag_limit' => array(
				'name' => __( 'Limit Tags', 'prdctfltr' ),
				'type' => 'number',
				'desc' => __( 'Limit number of tags to be shown. If limit is set tags with most posts will be shown first.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_tag_limit',
				'default' => 0,
				'custom_attributes' => array(
					'min' 	=> 0,
					'max' 	=> 100,
					'step' 	=> 1
				)
			),
			'prdctfltr_custom_tax' => array(
				'name' => __( 'Use Characteristics', 'prdctfltr' ),
				'type' => 'checkbox',
				'desc' => __( 'Enable this option to get custom characteristics product meta box.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_custom_tax',
				'default' => 'yes',
			),
			'prdctfltr_custom_tax_limit' => array(
				'name' => __( 'Limit Characteristics', 'prdctfltr' ),
				'type' => 'number',
				'desc' => __( 'Limit number of characteristics to be shown. If limit is set characteristics with most posts will be shown first.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_custom_tax_limit',
				'default' => 0,
				'custom_attributes' => array(
					'min' 	=> 0,
					'max' 	=> 100,
					'step' 	=> 1
				)
			),
			'section_filter_end' => array(
				'type' => 'sectionend',
				'id' => 'wc_settings_prdctfltr_filters_end'
			),
			'section_style_title' => array(
				'name'     => __( 'Product Filter Style', 'prdctfltr' ),
				'type'     => 'title',
				'desc'     => __( 'Select style preset to use. Use custom preset for your own style. Use Disable CSS to disable all CSS for product filter.', 'prdctfltr' ),
				'id'       => 'wc_settings_prdctfltr_style_title'
			),
			'prdctfltr_style_preset' => array(
				'name' => __( 'Select Style Preset', 'prdctfltr' ),
				'type' => 'select',
				'desc' => __( 'Select style preset to use or use Disable CSS option for custom settings.', 'prdctfltr' ),
				'id'   => 'wc_settings_prdctfltr_style_preset',
				'options' => array(
					'pf_disable' => __( 'Disable CSS', 'prdctfltr' ),
					'pf_arrow' => __( 'Arrow', 'prdctfltr' ),
					'pf_arrow_inline' => __( 'Arrow Inline', 'prdctfltr' ),
					'pf_border' => __( 'Border', 'prdctfltr' ),
					'pf_border_inline' => __( 'Border Inline', 'prdctfltr' ),
					'pf_default' => __( 'Flat', 'prdctfltr' ),
					'pf_default_inline' => __( 'Flat Inline', 'prdctfltr' ),

				),
				'default' => 'pf_default'
			),
			'section_style_end' => array(
				'type' => 'sectionend',
				'id' => 'wc_settings_prdctfltr_style_end'
			),


		);

		return apply_filters( 'wc_settings_products_filter_settings', $settings );
	}

}

WC_Settings_Prdctfltr::init();


// [prdctfltr_sc_products]
function prdctfltr_sc_products( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'ids' => '',
		'rows' => 4,
		'columns' => '4',
		'orderby' => 'menu_order',
		'order' => 'ASC',
		'meta_key'=> '',
		'ajax' => 'yes',
		'pagination' => 'yes',
		'use_filter' => 'yes',
		'no_products' => 'no',
		'min_price' => '',
		'max_price' => '',
		'bot_margin' => 36,
		'class' => '',
		'shortcode_id' => ''
	), $atts ) );

	if ( $min_price !== '' ) {
		$_GET['min_price'] = $min_price;
	}
	if ( $max_price !== '' ) {
		$_GET['max_price'] = $max_price;
	}

	if ( $ids == '' ) $ids = '0';
	$exploded = explode(',', $ids);

	global $paged;
	$args = array();
	if ( empty( $paged ) ) $paged = 1;

	if ( $no_products == 'no' ) {

		if ( isset($_GET['orderby']) ) {
			if ( $_GET['orderby'] == 'price' || $_GET['orderby'] == 'price-desc' ) {
				$orderby = 'meta_value_num';
				$order = ( $_GET['orderby'] == 'price' ? 'ASC' : 'DESC' );
				$args = array(
					'meta_key' => '_price'
				);
			}
			else if ( $_GET['orderby'] == 'rating' ) {
				add_filter( 'posts_clauses', array( WC()->query, 'order_by_rating_post_clauses' ) );
			}
			else if ( $_GET['orderby'] == 'popularity' ) {
				$orderby = 'meta_value_num';
				$order = 'DESC';
				$args = array(
					'meta_key' => 'total_sales'
				);
			}
			else if ( $_GET['orderby'] == 'menu_order' ) {
				$orderby = $orderby;
			}
			else {
				$orderby = $_GET['orderby'];
			}
		}

		if ( isset($_GET['min_price']) && isset($_GET['max_price']) ) {
			$orderby = 'meta_value_num';
			$order = 'ASC';
			$args['meta_query'] = array(
				array(
					'key' => '_price',
					'value' => array(floatval($_GET['min_price']), floatval($_GET['max_price'])),
					'type' => 'numeric',
					'compare' => 'BETWEEN'
				)
			);
		}

		if ( isset($_GET['product_tag']) ) {
			$args = array_merge( $args, array(
						'product_tag' => $_GET['product_tag']
				) );

		}

		if ( isset($_GET['characteristics']) ) {
			$args = array_merge( $args, array(
						'characteristics' => $_GET['characteristics']
				) );

		}

		if ( isset($_GET['sale_products']) ) {

			$meta_query = array(
				array(
					'key' => '_sale_price',
					'value' => 0,
					'compare' => '>',
					'type' => 'numeric'
				)
			);
			$args['meta_query'] = $meta_query;

		}

		if ( isset($_GET['product_cat']) ) {
			$args = $args + array(
				'tax_query' 			=> array(
					array(
						'taxonomy' 		=> 'product_cat',
						'terms' 		=> array( $_GET['product_cat'] ),
						'field' 		=> 'slug',
						'operator' 		=> 'IN'
					)
				)
			);
		}
		else if ( $ids !== '0' ) {
			$args = $args + array(
				'tax_query' 			=> array(
					array(
						'taxonomy' 		=> 'product_cat',
						'terms' 		=> $exploded,
						'field' 		=> 'slug',
						'operator' 		=> 'IN'
					)
				)
			);
		}

		foreach($_GET as $k => $v){
			if (strpos($k,'pa_') !== false) {
				$args = $args + array(
					'tax_query' 			=> array(
						array(
							'taxonomy' 		=> $k,
							'terms' 		=> $v,
							'field' 		=> 'slug',
							'operator' 		=> 'IN'
						)
					)
				);
			}
		}

	}
	else {
		$use_filter = 'no';
		$args['orderby'] = 'rand';
		$pagination = 'no';
	}

	if ( !isset($args['meta_query']) ) {
		$args['meta_query'] = WC()->query->get_meta_query();
	}

	global $prdctfltr_global;

	$prdctfltr_global = $columns*$rows;

	$args = $args + array(
		'post_type'				=> 'product',
		'post_status' 			=> 'publish',
		'ignore_sticky_posts'	=> 1,
		'orderby' 				=> $orderby,
		'order' 				=> $order,
		'posts_per_page' 		=> $prdctfltr_global,
		'paged' 				=> $paged,
		'meta_query' 			=> array(
			array(
				'key' 			=> '_visibility',
				'value' 		=> array('catalog', 'visible'),
				'compare' 		=> 'IN'
			)
		)
	);

	$query_string_ajax = http_build_query($args);

	$bot_margin = (int)$bot_margin;
	$margin = " style='margin-bottom".$bot_margin."px'";

	$out = '';
	$html_pag = '';

	global $woocommerce, $woocommerce_loop;
	
	$woocommerce_loop['columns'] = $columns;

	$products = new WP_Query( $args );
	

	if ( $pagination == 'true' ) {
		$html_pag = snpshpwp_mini_woo_pagination($products->max_num_pages, $paged, 3, $ajax);
	}

	ob_start();

	if ( $products->have_posts() ) : ?>

		<?php
			if ( $use_filter == 'yes' ) {
				wc_get_template( 'loop/orderby.php' );
			}
		?>

		<?php woocommerce_product_loop_start(); ?>

			<?php while ( $products->have_posts() ) : $products->the_post(); ?>

				<?php wc_get_template_part( 'content', 'product' ); ?>

			<?php endwhile; ?>

		<?php woocommerce_product_loop_end(); ?>

	<?php
	
	else :

		wc_get_template( 'loop/no-products-found.php' );

	endif;

	wp_reset_postdata();
	
	$shortcode = ob_get_clean();

	$out .= '<div' . ( $shortcode_id != '' ? ' id="'.$shortcode_id.'"' : '' ) . ' class="prdctfltr_sc_products woocommerce' . ( $class != '' ? ' '.$class.'' : '' ) . '">';
	$out .= do_shortcode($shortcode);

	if ( $pagination == 'yes' ) {

		ob_start();
		?>
		<nav class="woocommerce-pagination">
			<?php
				echo paginate_links( apply_filters( 'woocommerce_pagination_args', array(
					'base'         => str_replace( 999999999, '%#%', get_pagenum_link( 999999999 ) ),
					'format'       => '',
					'current'      => $paged,
					'total'        => $products->max_num_pages,
					'prev_text'    => '&larr;',
					'next_text'    => '&rarr;',
					'type'         => 'list',
					'end_size'     => 3,
					'mid_size'     => 3
				) ) );
			?>
		</nav>
		<?php
		$pagination = ob_get_clean();

		$out .= $pagination;

	}


	$out .= '</div>';
	return $out;

}
add_shortcode( 'prdctfltr_sc_products', 'prdctfltr_sc_products' );

// [prdctfltr_sc_get_filter]
function prdctfltr_sc_get_filter( $atts, $content = null ) {
	return prdctfltr_get_filter();
}
add_shortcode( 'prdctfltr_sc_get_filter', 'prdctfltr_sc_get_filter' );




class prdctfltr extends WP_Widget {

	function prdctfltr() {
		$widget_ops = array(
			'classname' => 'prdctfltr-widget',
			'description' => __( 'Product Filter widget version.', 'wdgtcstmzr' )
		);
		$this->WP_Widget( 'prdctfltr', '+ Product Filter', $widget_ops );
	}

	function widget( $args, $instance ) {
		extract( $args, EXTR_SKIP );
		$curr_pf = array (
			'preset' => $instance['preset'],
		);

		echo $before_widget;

		global $woocommerce, $wp_query, $wp;

		$curr_style = get_option( 'wc_settings_prdctfltr_style_preset', 'pf_default' );

		$catalog_orderby = apply_filters( 'prdctfltr_catalog_orderby', array(
			'' => __( 'None', 'prdctfltr' ),
			'menu_order' => __( 'Default', 'prdctfltr' ),
			'popularity' => __( 'Popularity', 'prdctfltr' ),
			'rating'     => __( 'Average rating', 'prdctfltr' ),
			'date'       => __( 'Newness', 'prdctfltr' ),
			'price'      => __( 'Price: low to high', 'prdctfltr' ),
			'price-desc' => __( 'Price: high to low', 'prdctfltr' )
		) );

		?>
		<div id="prdctfltr_woocommerce" class="prdctfltr_woocommerce woocommerce<?php echo ( $curr_pf['preset'] !== '' ? ' ' . $curr_pf['preset'] : ' pf_default_inline' ); ?>">
		<?php
			$curr_action = get_permalink( woocommerce_get_page_id( 'shop' ) );
			if ( $curr_action == home_url('/') && !is_page() ) {
				$post = get_post(woocommerce_get_page_id( 'shop' ));
				$curr_action = get_permalink( woocommerce_get_page_id( 'shop' ) ) . $post->post_name;
			}

			$curr_elements = get_option( 'wc_settings_prdctfltr_selected', array('sort','price','cat') );
			$curr_attrs = get_option( 'wc_settings_prdctfltr_attributes', array() );
		?>
		<form action="<?php echo $curr_action; ?>" class="prdctfltr_woocommerce_ordering<?php echo ( ( strpos( $curr_style, 'inline' ) !== true ) ? ' prdctfltr_columns_' . (count($curr_elements)+count($curr_attrs)) : '')?>" method="get">

			<?php
				foreach ( $curr_elements as $k => $v ) :
				
					switch ( $v ) :

					case 'sort' : ?>

						<div class="prdctfltr_orderby">
						<input name="orderby" type="hidden"<?php echo ( isset($_GET['orderby'] ) ? ' value="'.$_GET['orderby'].'"' : '' );?>>
						<?php echo $before_title; ?>
						<?php _e('Sort by', 'prdctfltr'); ?>
						<?php echo $after_title; ?>
						<?php
							if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' )
								unset( $catalog_orderby['rating'] );

							foreach ( $catalog_orderby as $id => $name ) {
								printf('<label%4$s><input type="checkbox" value="%1$s" %2$s /><span>%3$s</span></label>', esc_attr( $id ), ( isset($_GET['orderby']) && $_GET['orderby'] == $id ? 'checked' : '' ), esc_attr( $name ), ( isset($_GET['orderby']) && $_GET['orderby'] == $id ? ' class="prdctfltr_active"' : '' ) );
							}
						?>
						</div>

					<?php break;

					case 'price' :
					 ?>

						<div class="prdctfltr_byprice">
						<input name="min_price" type="hidden"<?php echo ( isset($_GET['min_price'] ) ? ' value="'.$_GET['min_price'].'"' : '' );?>>
						<input name="max_price" type="hidden"<?php echo ( isset($_GET['max_price'] ) ? ' value="'.$_GET['max_price'].'"' : '' );?>>
						<?php echo $before_title; ?>
						<?php _e('Price range', 'prdctfltr'); ?>
						<?php echo $after_title; ?>
						<?php
							$curr_price = ( isset($_GET['min_price']) ? $_GET['min_price'].'-'.( isset($_GET['max_price']) ? $_GET['max_price'] : '' ) : '' );
							
							$curr_price_set = get_option( 'wc_settings_prdctfltr_price_range', 100 );

							$curr_prices= array();
							
							for ($i = 1; $i <= 6; $i++) {
								$curr_prices[$i] = (($curr_price_set*$i)-$curr_price_set).'-'.( $i !== 6 ? ($curr_price_set*$i) : '' );
							}

							$catalog_price = apply_filters( 'prdctfltr_catalog_price', array(
								'-' => __( 'None', 'prdctfltr' ),
								$curr_prices[1] => str_replace('-',' - ',$curr_prices[1]),
								$curr_prices[2] => str_replace('-',' - ',$curr_prices[2]),
								$curr_prices[3] => str_replace('-',' - ',$curr_prices[3]),
								$curr_prices[4] => str_replace('-',' - ',$curr_prices[4]),
								$curr_prices[5] => str_replace('-',' - ',$curr_prices[5]),
								$curr_prices[6] => str_replace('-',' - +',$curr_prices[6])
							) );

							foreach ( $catalog_price as $id => $name ) {
								printf('<label%5$s><input type="checkbox" value="%1$s" %2$s /><span>%3$s %4$s</span></label>', esc_attr( $id ), ( $curr_price == $id ? 'checked' : '' ), esc_attr( $name ), ( $id !== '-' ? get_woocommerce_currency_symbol() : '' ), ( $curr_price == $id ? ' class="prdctfltr_active"' : '' ) );
							}
						?>
						</div>

					<?php break;

					case 'cat' : ?>

						<?php
							$curr_limit = get_option( 'wc_settings_prdctfltr_cat_limit', 0 );
							if ( $curr_limit !== 0 ) {
								$catalog_categories = get_terms( 'product_cat', array('hide_empty' => 1, 'orderby' => 'count', 'number' => $curr_limit ) );
							}
							else {
								$catalog_categories = get_terms( 'product_cat', array('hide_empty' => 1 ) );
							}

							if ( !empty( $catalog_categories ) && !is_wp_error( $catalog_categories ) ){
						?>
						<div class="prdctfltr_cat">
						<input name="product_cat" type="hidden"<?php echo ( isset($_GET['product_cat'] ) ? ' value="'.$_GET['product_cat'].'"' : '' );?>>
						<?php echo $before_title; ?>
						<?php _e('Categories', 'prdctfltr'); ?>
						<?php echo $after_title; ?>
						<?php
							printf('<label><input type="checkbox" value="" /><span>%1$s</span></label>', __('None' , 'prdctfltr') );
							foreach ( $catalog_categories as $term ) {
								printf('<label%4$s><input type="checkbox" value="%1$s" %3$s /><span>%2$s</span></label>', $term->slug, $term->name, ( isset($_GET['product_cat']) && $_GET['product_cat'] == $term->slug ? 'checked' : '' ), ( isset($_GET['product_cat']) && $_GET['product_cat'] == $term->slug ? ' class="prdctfltr_active"' : '' ) );
							}
						?>
						</div>
						<?php
						}
						?>

					<?php break;

					case 'tag' : ?>

						<?php
							$curr_limit = get_option( 'wc_settings_prdctfltr_tag_limit', 0 );
							if ( $curr_limit !== 0 ) {
								$catalog_tags = get_terms( 'product_tag', array('hide_empty' => 1, 'orderby' => 'count', 'number' => $curr_limit ) );
							}
							else {
								$catalog_tags = get_terms( 'product_tag', array('hide_empty' => 1 ) );
							}

							if ( !empty( $catalog_tags ) && !is_wp_error( $catalog_tags ) ){
						?>
						<div class="prdctfltr_tag">
						<input name="product_tag" type="hidden"<?php echo ( isset($_GET['product_tag'] ) ? ' value="'.$_GET['product_tag'].'"' : '' );?>>
						<?php echo $before_title; ?>
						<?php _e('Tags', 'prdctfltr'); ?>
						<?php echo $aftere_title; ?>
						<?php
							printf('<label><input type="checkbox" value="" /><span>%1$s</span></label>', __('None' , 'prdctfltr') );
							foreach ( $catalog_tags as $term ) {
								printf('<label%4$s><input type="checkbox" value="%1$s" %3$s /><span>%2$s</span></label>', $term->slug, $term->name, ( isset($_GET['product_tag']) && $_GET['product_tag'] == $term->slug ? 'checked' : '' ), ( isset($_GET['product_tag']) && $_GET['product_tag'] == $term->slug ? ' class="prdctfltr_active"' : '' ) );
							}
						?>
						</div>
						<?php
						}
						?>

					<?php break;

					case 'char' : ?>

						<?php
							$curr_limit = get_option( 'wc_settings_prdctfltr_custom_tax_limit', 0 );
							if ( $curr_limit !== 0 ) {
								$catalog_characteristics = get_terms( 'characteristics', array('hide_empty' => 1, 'orderby' => 'count', 'number' => $curr_limit ) );
							}
							else {
								$catalog_characteristics = get_terms( 'characteristics', array('hide_empty' => 1 ) );
							}

							if ( !empty( $catalog_characteristics ) && !is_wp_error( $catalog_characteristics ) ){
						?>
						<div class="prdctfltr_characteristics">
						<input name="characteristics" type="hidden"<?php echo ( isset($_GET['characteristics'] ) ? ' value="'.$_GET['characteristics'].'"' : '' );?>>
						<?php echo $before_title; ?>
						<?php _e('Characteristics', 'prdctfltr'); ?>
						<?php echo $after_title; ?>
						<?php
							printf('<label><input type="checkbox" value="" /><span>%1$s</span></label>', __('None' , 'prdctfltr') );
							foreach ( $catalog_characteristics as $term ) {
								printf('<label%4$s><input type="checkbox" value="%1$s" %3$s /><span>%2$s</span></label>', $term->slug, $term->name, ( isset($_GET['characteristics']) && $_GET['characteristics'] == $term->slug ? 'checked' : '' ), ( isset($_GET['characteristics']) && $_GET['characteristics'] == $term->slug ? ' class="prdctfltr_active"' : '' ) );
							}
						?>
						</div>
						<?php
						}
						?>

					<?php break;

					default :
					break;

					endswitch;
				
				endforeach;

				$n = 0;
				foreach ( $curr_attrs as $k => $attr ) :

					$n++;

					$curr_attributes = get_terms( $attr );
					
					$curr_term = get_taxonomy( $attr );
			?>
						<div class="prdctfltr_attributes prdctfltr_attributes_<?php echo $n; ?>">
						<input name="<?php echo $attr; ?>" type="hidden"<?php echo ( isset($_GET[$attr] ) ? ' value="'.$_GET[$attr].'"' : '' );?>>
						<?php echo $before_title; ?>
						<?php echo $curr_term->label; ?>
						<?php echo $after_title; ?>
						<?php
							printf('<label><input type="checkbox" value="" /><span>%1$s</span></label>', __('None' , 'prdctfltr') );
							foreach ( $curr_attributes as $attribute ) {
								printf('<label%4$s><input type="checkbox" value="%1$s" %3$s /><span>%2$s</span></label>', $attribute->slug, $attribute->name, ( isset($_GET[$attr]) && $_GET[$attr] == $attribute->slug ? 'checked' : '' ), ( isset($_GET[$attr]) && $_GET[$attr] == $attribute->slug ? ' class="prdctfltr_active"' : '' ) );
							}
						?>
						</div>
						<?php
				endforeach;
			?>
			<div class="prdctfltr_clear"></div>
			<a id="prdctfltr_woocommerce_filter_submit" class="button" href="#"><?php _e('Filter selected', 'prdctfltr'); ?></a>
			<span class="prdctfltr_sale">
				<?php
				printf('<label%2$s><input name="sale_products" type="checkbox"%3$s/><span>%1$s</span></label>', __('Show only products on sale' , 'prdctfltr'), ( isset($_GET['sale_products']) ? ' class="prdctfltr_active"' : '' ), ( isset($_GET['sale_products']) ? ' checked' : '' ) );
				?>
			</span>
		</form>
		</div>
	<?php

		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['preset'] =  $new_instance['preset'];

		return $instance;
	}

	function form( $instance ) {
		$vars = array( 'preset' => '' );
		$instance = wp_parse_args( (array) $instance, $vars );

		$preset = strip_tags($instance['preset']);

?>
		<div>
			<p class="prdctfltr-box">
			<label for="<?php echo $this->get_field_id('preset'); ?>" class="prdctfltr-label"><?php _e('Preset:'); ?></label>
			<select name="<?php echo $this->get_field_name('preset'); ?>" id="<?php echo $this->get_field_id('preset'); ?>">
				<option value="pf_default_inline"<?php echo ( $preset == 'pf_default_inline' ? ' selected="selected"' : '' ); ?>><?php _e('Inline', 'prdctfltr'); ?></option>
				<option value="pf_default"<?php echo ( $preset == 'pf_default' ? ' selected="selected"' : '' ); ?>><?php _e('Block', 'prdctfltr'); ?></option>
			</select>
			</p>
		</div>

<?php
	}
}
add_action( 'widgets_init', create_function('', 'return register_widget("prdctfltr");' ) );


?>