<?php   

/*

Plugin Name: Frontend Builder Woo Commerce Ext

Plugin URI:

Description: An extension for Frontend Builder WordPress Plugin that implements Woo Commerce shortcodes.

Author: Urban Graphic

Version: 1.10

Author URI: 

*/

global $fbuilderCommerce;

if (!class_exists("FrontendBuilderCommerce")) {

	require_once dirname( __FILE__ ) . '/frontend_builder_commerce_class.php';	

	$fbuilderCommerce = new FrontendBuilderCommerce(__FILE__);

}



?>