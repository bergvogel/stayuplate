<?php

class FrontendBuilderCommerce {

var $main, $path, $name, $url;

function __construct($file) {
	$this->main = $file;
	global $fbuilder;
	load_plugin_textdomain( 'frontend-builder', false, dirname( plugin_basename( $fbuilder->path ) ) . '/languages/' );

	$this->path = dirname( __FILE__ );
	$this->name = basename( $this->path );
	$this->url = plugins_url( "/{$this->name}/" );

	// 	Multisite and woocommerce check
	define( "FRBWOO_MULTISITE", ( is_multisite() ? true : false ) );
	$using_woo = false;
	if ( FRBWOO_MULTISITE === true ) {
		if ( array_key_exists( 'woocommerce/woocommerce.php', maybe_unserialize( get_site_option( 'active_sitewide_plugins') ) ) ) {
			$using_woo = true;
	 	} elseif ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ? 'active' : '' ) {
			$using_woo = true;
		}
	} elseif ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ? 'active' : '' ) {
		$using_woo = true;
	}
	define( "FRBWOO_WOOCOMMERCE", $using_woo );

	register_activation_hook( $this->main , array(&$this, 'wp_activate') );
	register_deactivation_hook( $this->main , array(&$this, 'wp_deactivate') );

	if(isset($fbuilder) && FRBWOO_WOOCOMMERCE === true) {
		array_push($fbuilder ->groups, array(
				'id' => 'woo_extension', 
				'label' => __('Woo Extension', 'frontend-builder'),
				'img' => $this->url . 'images/woo_extension-shortcodes.png'
			)
		);

	add_action('init', array(&$this, 'FRBEProductQuery'));
	add_action('init', array(&$this, 'frontend_includes'));
	add_action('wp_ajax_frbwoo_quickview_dataset', array(&$this, 'ajaxQuickviewDataset'));
	add_action('wp_ajax_nopriv_frbwoo_quickview_dataset', array(&$this, 'ajaxQuickviewDataset')); 
	}
	return $this;
}

function get_shortcode_list() {
	$output = '{}';
	require($this->path .'/shortcodes/shortcode_list.php');
	return $output;
}

function get_admin_list() {
	$output = array();
	require($this->path .'/functions/admin_control_list.php');
	return $output;
}

function get_font_head() {
	$output = '';
	require_once($this->path .'/functions/font_head.php');
	return $output;
}

function wp_activate() {
	$this -> registerFrbExtension();
}

function wp_deactivate() {
	$this -> unregisterFrbExtension();
}

function frontend_includes() {
	global $fbuilder;
	require($this->path .'/shortcodes/shortcodes.php');
	if (isset($fbuilder)) {
		$fbuilder->add_new_shortcodes($this->get_shortcode_list());
	}

	wp_enqueue_style('frbe_product_font', $this->url . 'fonts/product/style.css');
	wp_enqueue_style('frbe_shortcode_css', $this->url . 'shortcodes/shortcodes.css');

	wp_enqueue_script('fbuilder_swiper_js', $fbuilder->url . 'js/idangerous.swiper.js', array('jquery'),'2.5', true);
	wp_enqueue_script('fbuilder_isotope_js', $this->url . 'js/isotope.pkgd.min.js', array('jquery'),'2.0', true);
	wp_enqueue_script('frbe_shortcode_js', $this->url . 'shortcodes/shortcodes.js', array('jquery', 'fbuilder_swiper_js'),'1.0', true);
}
	
function FRBEProductQuery(){
	global $fbuilderCommerce;
	$args = array(
		'taxonomy' => 'product_cat',
		'orderby' => 'title',
	);

	$the_query = new WP_Query( $args );

	$frbe_product_slider_query = get_categories($args); 
	$frbe_product_slider_final_query = array();
	$frbe_product_category_slug = array(); 
	foreach ( $frbe_product_slider_query as $category ) {
			$frbe_product_slider_final_query = $frbe_product_slider_final_query + array($category->term_id=>$category->name); 
			$frbe_product_category_slug = $frbe_product_category_slug + array($category->term_id => $category->slug);
	}
	$fbuilderCommerce -> productCategoriesQuery = $frbe_product_slider_final_query;
	$fbuilderCommerce -> productCategorySlugbyID = $frbe_product_category_slug;

	wp_reset_postdata();	
}

function registerFrbExtension() {
	global $wpdb;
	$table_name = $wpdb->prefix . 'frontend_builder_extensions';
	$wpdb->replace( $table_name, array('name' => 'fbuilder_woocommerce', 'admin_controls_list_url' => $this->path .'/functions/admin_control_list.php', 'font_head_url' => $this->path .'/functions/font_head.php'));	
	return NULL;

}

function unregisterFrbExtension() {
	global $wpdb;
	$table_name = $wpdb->prefix . 'frontend_builder_extensions';
	$wpdb->delete( $table_name, array('name' => 'fbuilder_woocommerce'));	
	return NULL;
}

function ajaxQuickviewDataset() {
	$currId = $_POST['ids'];
	$currId = explode(',',$currId);
	$output = array();
	foreach($currId as $key => $value) {
		$product = get_product( $value );
		$quickview_add_to_cart = sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="button %s product_type_%s">%s</a>',
			esc_url( $product->add_to_cart_url() ),
			esc_attr( $product->id ),
			esc_attr( $product->get_sku() ),
			$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
			esc_attr( $product->product_type ),
			esc_html( $product->add_to_cart_text() )
		);

		$quickview_price = '<div itemprop="offers" itemscope itemtype="http://schema.org/Offer">';
		$quickview_price .= '<p class="price">'.$product->get_price_html().'</p>';
		$quickview_price .= ($product->is_in_stock() ? '' : '<span class="outofstock">'.__('Out of stock', 'frontend-builder').'</span>' );
		$quickview_price .= '</div>';

		$quickview_title = get_the_title($value);
		$quickview_title_url = get_the_permalink($value);

		$quickview_cat = $product->get_categories();

		$quickview_content = $product->post->post_content;

		$quickview_gallery = array();
		if ( has_post_thumbnail($value) ) {
			array_push($quickview_gallery, get_the_post_thumbnail( $value, 'full'));
		}
		$quickview_attachments = $product->get_gallery_attachment_ids($value);
		foreach ($quickview_attachments as $attID) {
			array_push($quickview_gallery, wp_get_attachment_image( $attID, 'full'));
		}
		$elementData = array(
			'content' => $quickview_content,
			'title' => $quickview_title,
			'title_url' => $quickview_title_url,
			'categories' => $quickview_cat,
			'price' => $quickview_price,
			'gallery' => $quickview_gallery,
			'add_to_cart' => $quickview_add_to_cart
		);
		array_push($output, $elementData);
	}

	
die(json_encode($output));
}



}

?>