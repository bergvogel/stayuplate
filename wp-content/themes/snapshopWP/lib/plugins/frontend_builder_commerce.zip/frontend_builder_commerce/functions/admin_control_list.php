<?php

$fbuildercommerce_admin_options = array(
	'font' => array(
		'label' => __('Typography options','frontend-builder'),
		'desc' => __('Font and typography settings for each shortcode. The "Default" option will use the theme fonts.','frontend-builder'),
		'options' => array(
			array(
				'type' => 'heading',
				'label' => __('FRB-Woo Product Slider','frontend-builder')
			),
			array(
				'type' => 'collapsible',
				'label' => __('Title font','frontend-builder'),
				'options' => array(
					array(
						'name' => 'FRB-Woo_product_slider_title_font_family',
						'class' => 'fbuilder_font_select',
						'type' => 'select', 'search' => 'true',
						'std' => 'default',
						'label' => __('Font family','frontend-builder'),
						'options' => $fbuilder_google_font_names
					),
					array(
						'name' => 'FRB-Woo_product_slider_title_font_style',
						'type' => 'select',
						'std' => 'default',
						'label' => __('Font style','frontend-builder'),
						'options' => $this->get_font_variants('FRB-Woo_product_slider_title_font_family',$fbuilder_google_font_variants),
						'hide_if' => array(
							'FRB-Woo_product_slider_title_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_product_slider_title_font_size',
						'type' => 'number',
						'label' => __('Font size','frontend-builder'),
						'std' => 20,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_product_slider_title_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_product_slider_title_line_height',
						'type' => 'number',
						'label' => __('Line height','frontend-builder'),
						'std' => 24,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_product_slider_title_font_family' => array('default')
						)
					)
				)
			), // title font
			array(
				'type' => 'collapsible',
				'label' => __('Category font','frontend-builder'),
				'options' => array(
					array(
						'name' => 'FRB-Woo_product_slider_cat_font_family',
						'class' => 'fbuilder_font_select',
						'type' => 'select', 'search' => 'true',
						'std' => 'default',
						'label' => __('Font family','frontend-builder'),
						'options' => $fbuilder_google_font_names
					),
					array(
						'name' => 'FRB-Woo_product_slider_cat_font_style',
						'type' => 'select',
						'std' => 'default',
						'label' => __('Font style','frontend-builder'),
						'options' => $this->get_font_variants('FRB-Woo_product_slider_cat_font_family',$fbuilder_google_font_variants),
						'hide_if' => array(
							'FRB-Woo_product_slider_cat_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_product_slider_cat_font_size',
						'type' => 'number',
						'label' => __('Font size','frontend-builder'),
						'std' => 14,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_product_slider_cat_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_product_slider_cat_line_height',
						'type' => 'number',
						'label' => __('Line height','frontend-builder'),
						'std' => 18,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_product_slider_cat_font_family' => array('default')
						)
					)
				)
			), // category font
			array(
				'type' => 'collapsible',
				'label' => __('Price font','frontend-builder'),
				'options' => array(
					array(
						'name' => 'FRB-Woo_product_slider_price_font_family',
						'class' => 'fbuilder_font_select',
						'type' => 'select', 'search' => 'true',
						'std' => 'default',
						'label' => __('Font family','frontend-builder'),
						'options' => $fbuilder_google_font_names
					),
					array(
						'name' => 'FRB-Woo_product_slider_price_font_style',
						'type' => 'select',
						'std' => 'default',
						'label' => __('Font style','frontend-builder'),
						'options' => $this->get_font_variants('FRB-Woo_product_slider_price_font_family',$fbuilder_google_font_variants),
						'hide_if' => array(
							'FRB-Woo_product_slider_price_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_product_slider_price_font_size',
						'type' => 'number',
						'label' => __('Font size','frontend-builder'),
						'std' => 14,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_product_slider_price_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_product_slider_price_line_height',
						'type' => 'number',
						'label' => __('Line height','frontend-builder'),
						'std' => 18,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_product_slider_price_font_family' => array('default')
						)
					)
				)
			), // price font
			array(
				'type' => 'button',
				'class' => 'fbuilder_save',
				'label' => __('Save options','frontend-builder')
			),	// product slider END
			array(
				'type' => 'heading',
				'label' => __('FRB-Woo Products','frontend-builder')
			),
			array(
				'type' => 'collapsible',
				'label' => __('Title font','frontend-builder'),
				'options' => array(
					array(
						'name' => 'FRB-Woo_products_title_font_family',
						'class' => 'fbuilder_font_select',
						'type' => 'select', 'search' => 'true',
						'std' => 'default',
						'label' => __('Font family','frontend-builder'),
						'options' => $fbuilder_google_font_names
					),
					array(
						'name' => 'FRB-Woo_products_title_font_style',
						'type' => 'select',
						'std' => 'default',
						'label' => __('Font style','frontend-builder'),
						'options' => $this->get_font_variants('FRB-Woo_products_title_font_family',$fbuilder_google_font_variants),
						'hide_if' => array(
							'FRB-Woo_products_title_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_products_title_font_size',
						'type' => 'number',
						'label' => __('Font size','frontend-builder'),
						'std' => 20,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_products_title_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_products_title_line_height',
						'type' => 'number',
						'label' => __('Line height','frontend-builder'),
						'std' => 24,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_products_title_font_family' => array('default')
						)
					)
				)
			), // title font
			array(
				'type' => 'collapsible',
				'label' => __('Price font','frontend-builder'),
				'options' => array(
					array(
						'name' => 'FRB-Woo_products_price_font_family',
						'class' => 'fbuilder_font_select',
						'type' => 'select', 'search' => 'true',
						'std' => 'default',
						'label' => __('Font family','frontend-builder'),
						'options' => $fbuilder_google_font_names
					),
					array(
						'name' => 'FRB-Woo_products_price_font_style',
						'type' => 'select',
						'std' => 'default',
						'label' => __('Font style','frontend-builder'),
						'options' => $this->get_font_variants('FRB-Woo_products_price_font_family',$fbuilder_google_font_variants),
						'hide_if' => array(
							'FRB-Woo_products_price_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_products_price_font_size',
						'type' => 'number',
						'label' => __('Font size','frontend-builder'),
						'std' => 14,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_products_price_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_products_price_line_height',
						'type' => 'number',
						'label' => __('Line height','frontend-builder'),
						'std' => 18,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_products_price_font_family' => array('default')
						)
					)
				)
			), // price font
			array(
				'type' => 'button',
				'class' => 'fbuilder_save',
				'label' => __('Save options','frontend-builder')
			),	//	products -- END
			array(
				'type' => 'heading',
				'label' => __('FRB-Woo Product Categories','frontend-builder')
			),
			array(
				'type' => 'collapsible',
				'label' => __('Title font','frontend-builder'),
				'options' => array(
					array(
						'name' => 'FRB-Woo_product_categories_title_font_family',
						'class' => 'fbuilder_font_select',
						'type' => 'select', 'search' => 'true',
						'std' => 'default',
						'label' => __('Font family','frontend-builder'),
						'options' => $fbuilder_google_font_names
					),
					array(
						'name' => 'FRB-Woo_product_categories_title_font_style',
						'type' => 'select',
						'std' => 'default',
						'label' => __('Font style','frontend-builder'),
						'options' => $this->get_font_variants('FRB-Woo_product_categories_title_font_family',$fbuilder_google_font_variants),
						'hide_if' => array(
							'FRB-Woo_product_categories_title_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_product_categories_title_font_size',
						'type' => 'number',
						'label' => __('Font size','frontend-builder'),
						'std' => 20,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_product_categories_title_font_family' => array('default')
						)
					),
					array(
						'name' => 'FRB-Woo_product_categories_title_line_height',
						'type' => 'number',
						'label' => __('Line height','frontend-builder'),
						'std' => 24,
						'unit' => 'px',
						'hide_if' => array(
							'FRB-Woo_product_categories_title_font_family' => array('default')
						)
					)
				)
			), // title font
			array(
				'type' => 'button',
				'class' => 'fbuilder_save',
				'label' => __('Save options','frontend-builder')
			)
			
		)
	)
);



return $fbuildercommerce_admin_options;

?>