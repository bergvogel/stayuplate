<?php


if(array_key_exists('FRB-Woo_product_slider_title', $admin_fonts) && $admin_fonts['FRB-Woo_product_slider_title'] != 'default')
	$output .= '
	#fbuilder_wrapper .frbe_product_slide_title {
		'.$admin_fonts['FRB-Woo_product_slider_title'].'
	}';

if(array_key_exists('FRB-Woo_product_slider_cat', $admin_fonts) && $admin_fonts['FRB-Woo_product_slider_cat'] != 'default')
	$output .= '
	#fbuilder_wrapper .frbe_product_slider_cat {
		'.$admin_fonts['FRB-Woo_product_slider_cat'].'
	}';

if(array_key_exists('FRB-Woo_product_slider_price', $admin_fonts) && $admin_fonts['FRB-Woo_product_slider_price'] != 'default')
	$output .= '
	#fbuilder_wrapper .frbe_product_slider_regular_price, 
	#fbuilder_wrapper .frbe_product_slider_sale_price {
		'.$admin_fonts['FRB-Woo_product_slider_price'].'
	}';




if(array_key_exists('FRB-Woo_products_title', $admin_fonts) && $admin_fonts['FRB-Woo_products_title'] != 'default')
	$output .= '
	#fbuilder_wrapper .frbe_products_list ul li h3 {
		'.$admin_fonts['FRB-Woo_products_title'].'
	}';

if(array_key_exists('FRB-Woo_products_price', $admin_fonts) && $admin_fonts['FRB-Woo_products_price'] != 'default')
	$output .= '
	#fbuilder_wrapper .frbe_products_list ul.products .price {
		'.$admin_fonts['FRB-Woo_products_price'].'
	}';




if(array_key_exists('FRB-Woo_product_categories_title', $admin_fonts) && $admin_fonts['FRB-Woo_product_categories_title'] != 'default')
	$output .= '
	#fbuilder_wrapper .frbe_product_categories h3 {
		'.$admin_fonts['FRB-Woo_product_categories_title'].'
	}';
?>