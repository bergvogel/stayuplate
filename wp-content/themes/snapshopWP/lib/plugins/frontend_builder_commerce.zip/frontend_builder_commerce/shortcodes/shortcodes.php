<?php

function frbe_product_slider( $atts, $content=null ) {
	
	global $fbuilderCommerce, $fbuilder;
	foreach ($fbuilderCommerce -> productCategoriesQuery as $key => $val) {
		$frbe_product_slider_default = $key;
		break;
	}
	
	$admin_optionsDB = $fbuilder->option();
	$opts = array();
	foreach($admin_optionsDB as $opt) {
		if(isset($opt->name) && isset($opt->value))
			$opts[$opt->name] = $opt->value;
	}

	extract (shortcode_atts( array(
		'bot_margin' => 24,
		'shortcode_id' => '',
		'class' => '',
		'animate' => 'none',
		'animation_delay' => 0,
		'animation_group' => '',
		'animation_speed' => 1000,
		'slides_per_view' => '3',
		'item_align' => 'center',
		'item_spacing' => '20px',
		'title_size' => '20px',
		'title_line_height' => '24px',
		'cat_line_height' => '18px',
		'cat_size' => '14px',
		'price_line_height' => '18px',
		'price_size' => '14px',
		'title_color' => '#111111',
		'category_color' => '#111111',
		'price_color' => '#111111',
		'products_from' =>'category',
		'categories' => $frbe_product_slider_default,
		'category_order' => 'desc',
		'number_of_posts' => 5,
		'category_show' => 'true',
		'aspect_ratio' => '1:1',
		'resize_reference' => '200px'
	), $atts));
	
	$bot_margin = (int)$bot_margin.'px';
	$title_size = (int)$title_size.'px';
	$title_line_height = (int)$title_line_height.'px';
	$cat_size = (int)$cat_size.'px';
	$cat_line_height = (int)$cat_line_height.'px';
	$price_line_height = (int)$price_line_height.'px';
	$price_size = (int)$price_size.'px';
	$randomId = $shortcode_id == '' ? 'frbe_product_slider_'.rand() : $shortcode_id;
	$slides_per_view = (int)$slides_per_view;
	$number_of_posts = (int)$number_of_posts;
	$category_show = $category_show == 'true' ? true : false;
	$aspect_ratio = in_array($aspect_ratio, array('1:1', '16:9', '1:1.5'), true) ? $aspect_ratio : '1:1.5';
	$item_align = in_array($item_align, array('center', 'left', 'right'), true) ? $item_align : 'center';
	$category_order = in_array($category_order, array('asc', 'desc'), true) ? $category_order : 'desc';
	$resize_reference = (int)$resize_reference;
	$item_spacing = (int)$item_spacing;
	
	
	if($animate != 'none') {
		$animate = ' frb_animated frb_'.$animate.'"';
		
		if($animation_delay != 0) {
			$animation_delay = (int)$animation_delay;
			$animate .= ' data-adelay="'.$animation_delay.'"';
		}
		if($animation_group != '') {
			$animate .= ' data-agroup="'.$animation_group.'"';
		}
	}
	else
		$animate = '"';
		
		$animSpeedSet = '#'.$randomId.'.frb_onScreen.frb_animated {-webkit-animation-duration: '.(int)$animation_speed.'ms; animation-duration: '.(int)$animation_speed.'ms;}'.
						'#'.$randomId.'.frb_onScreen.frb_hinge {-webkit-animation-duration: '.((int)$animation_speed*2).'ms; animation-duration: '.((int)$animation_speed*2).'ms;}';
	$animSpeedSet = (int)$animation_speed != 0 ? $animSpeedSet : '';

	$style = '
				#'.$randomId.' .slider_arrow_next {right:'.($item_spacing/2).'px;}
				#'.$randomId.' .slider_arrow_prev {left:'.($item_spacing/2).'px;}
				#'.$randomId.' .frbe_product_slider_cat {color:'.$category_color.';}
				#'.$randomId.' .frbe_product_slide_title {color:'.$title_color.';}
				#'.$randomId.' .frbe_product_slider_regular_price, .frbe_product_slider_sale_price {color:'.$price_color.';}
				.frbe_product_quickview_wrapper .outofstock {background-color:'.$opts['main_color'].';}';

	$html ='';
	$html .= '<style type="text/css">'.$animSpeedSet.$style.'</style><div id="'.$randomId.'" class="frbe_product_slider_container'.$class.$animate.' data-spv="'.$slides_per_view.'" data-asr="'.$aspect_ratio.'" data-rref="'.$resize_reference.'" style="padding-bottom:'.$bot_margin.'"><div class="frbe_product slider_arrow_prev"><img class="slider_arrow_img" src="'.$fbuilderCommerce->url.'images/shortcode/left.png'.'" alt="<" /></div><div class="frbe_product slider_arrow_next"><img class="slider_arrow_img" src="'.$fbuilderCommerce->url.'images/shortcode/right.png'.'" alt=">" /></div><div class="frbe_product_slider_wrapper">';
	
	$cnt = 0;
	
	global $woocommerce, $fbuilder;
	$cart_url = $woocommerce->cart->get_cart_url();
	$args = array(
		'posts_per_page' => $number_of_posts,
		'post_type' => 'product',
		'order' => $category_order,
		'orderby' => 'title'
	);
	switch ($products_from) {
		case 'category': $metaFilter = NULL; $args['tax_query'] = array(
															array(
																'taxonomy' => 'product_cat',
																'field' => 'term_id',
																'terms' => $categories
															)
														); break;
		case 'featured': $args['meta_key'] = '_featured'; $args['meta_value'] = 'yes'; break;
		case 'sales': $args['meta_query'] = array(
									'relation' => 'OR', 
									array('key' => '_sale_price', 'value' => 0, 'compare' => '>', 'type' => 'numeric'),
							        array('key' => '_min_variation_sale_price', 'value' => 0, 'compare' => '>', 'type' => 'numeric')
    							); break;
	}
	$product_ids = '';
	$the_query = new WP_Query( $args );
	while ( $the_query->have_posts() ) {
		$the_query->the_post();
		$cat =  wp_get_post_terms(get_the_ID(), 'product_cat');
		$meta = get_post_meta( get_the_ID());
		$currency = get_woocommerce_currency_symbol();	  
	
	


		$product = get_product(get_the_ID());
		$product_ids .=','.get_the_ID();
	

		$fbuilder_options = $fbuilder -> option();
	  	
		$catString = '';
		if($category_show === true) {
			
			foreach($cat as $catGroup) {
				$catString .= ' <a href="'.get_term_link($catGroup).'" class="frbe_product_slider_cat">'.($catGroup -> name). '</a>,';
				
			}
			
			if(substr($catString, -1) === ','){
				$catString = substr($catString, 0, -1);
			}	
		}


		

		$add_to_cart_on_slide = sprintf( '<a href="%1s" rel="nofollow" data-product_id="%2s" data-product_sku="%3s" class="frbe_product_slider_add_to_cart button %4s product_type_%5s"><i class="products-shop2"></i><span><span>%6s</span></span></a>',
							esc_url($product->add_to_cart_url()),
							esc_attr($product->id),
							esc_attr($product->get_sku()),
							$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
							esc_attr($product->product_type),
							esc_html($product->add_to_cart_text())
						);


		$html .= '<div class="frbe_product_slide" data-colind="'.$cnt.'">'
					.'<div class="frbe_product_slide_inner" style="padding:0 '.($item_spacing/2).'px; overflow:hidden;">'
						.'<span class="frbe_product_slide_img_wrapper" data-product-href="'.get_permalink(get_the_ID()).'">'
							.get_the_post_thumbnail(get_the_ID(),'full')
							.'<span class="frbe_product_quickview">+<span><span>'.__('QUICK LOOK','frontend-builder').'</span></span></span>';

			
					$html.= $add_to_cart_on_slide;
					 



					// $html.= '<a class="frbe_product_slider_view_cart" href="'.$cart_url.'" data-product_sku="'.$meta['_sku'][0].'" data-product_id="'.get_the_ID().'" rel="nofollow"></a>';

					$html.= '</span>'
							.'<div class="frbe_product_slide_text_wrapper" style=" text-align:'.$item_align.';">'
								.'<span style="width:100%; display:block;">'.$catString.'</span>'
								.'<a href="'.get_permalink(get_the_ID()).'" class="frbe_product_slide_title">'.get_the_title().'</a>'
								.(isset($meta['_min_variation_sale_price'][0]) && $meta['_min_variation_sale_price'][0] != '' ? '<span class="frbe_product_slider_regular_price crossed">'.$meta['_min_variation_regular_price'][0].$currency.'</span> - <span class="frbe_product_slider_regular_price crossed">'.$meta['_max_variation_regular_price'][0].$currency.'</span>'.' <span class="frbe_product_slider_sale_price">'.$meta['_min_variation_sale_price'][0].$currency.'</span> - <span class="frbe_product_slider_sale_price">'.$meta['_max_variation_sale_price'][0].$currency.'</span>' : '<span class="frbe_product_slider_regular_price'.($meta['_sale_price'][0] != '' ? ' crossed' : '').'">'.$meta['_regular_price'][0].$currency.'</span>'.($meta['_sale_price'][0] != '' ? ' <span class="frbe_product_slider_sale_price">'.$meta['_sale_price'][0].$currency.'</span>' : ''))
								
								.'<div class="frb_clear"></div>'
							.'</div>'
						.'</div>'
					.'</div>';
					
			
	  	$cnt++;		
	}
	wp_reset_postdata();	


	$product_ids = substr($product_ids, 1);
	$script='<script>
				(function($){
					$(document).ready(function(){
						if($(this).find(".frbe_product_slider_container").length > 0) {
							$("#'.$randomId.'.frbe_product_slider_container").frbeProductSlider();
							$.post(ajaxurl, {action:"frbwoo_quickview_dataset", ids : "'.$product_ids.'"} , function(response) {
								$("#'.$randomId.'.frbe_product_slider_container").data("product_content", response);
							}, "json");
							$("#'.$randomId.'.frbe_product_slider_container").frbeProductSliderResize();			
						}
					});
					$(window).resize(function(){
						$("#'.$randomId.'.frbe_product_slider_container").each(function(){
							$(this).frbeProductSliderResize();
						});
					});
					$(document).on("row_width_change", ".fbuilder_row", function() {
						$(this).find("#'.$randomId.'.frbe_product_slider_container").frbeProductSliderResize();
					});
				})(jQuery);
			</script>';	
	$html .= '</div></div>'.$script;	
	return $html;
}
add_shortcode( 'frbe_product_slider', 'frbe_product_slider' );




function frbe_product_grid( $atts, $content=null ) {
	
	global $fbuilderCommerce, $fbuilder;
	foreach ($fbuilderCommerce -> productCategoriesQuery as $key => $val) {
		$frbe_product_grid_default = $key;
		break;
	}

	$admin_optionsDB = $fbuilder->option();
	$opts = array();
	foreach($admin_optionsDB as $opt) {
		if(isset($opt->name) && isset($opt->value))
			$opts[$opt->name] = $opt->value;
	}

	extract (shortcode_atts( array(
		'bot_margin' => 24,
		'shortcode_id' => '',
		'class' => '',
		'animate' => 'none',
		'animation_delay' => 0,
		'animation_group' => '',
		'animation_speed' => 1000,
		'products_from' =>'category',
		'categories' => $frbe_product_grid_default,
		'category_order' => 'desc',
		'number_of_posts' => 5
	), $atts));
	
	$bot_margin = (int)$bot_margin.'px';
	$randomId = $shortcode_id == '' ? 'frbe_product_grid_'.rand() : $shortcode_id;
	$number_of_posts = (int)$number_of_posts;
	$category_order = in_array($category_order, array('asc', 'desc'), true) ? $category_order : 'desc';
	
	$layout_1 = array("single","half","double","half","half","half", "double", "single","half","half","single");
	$column_number_1 = 3;


	$layout = $layout_1;
	$column_number = $column_number_1;

	if($animate != 'none') {
		$animate = ' frb_animated frb_'.$animate.'"';
		
		if($animation_delay != 0) {
			$animation_delay = (int)$animation_delay;
			$animate .= ' data-adelay="'.$animation_delay.'"';
		}
		if($animation_group != '') {
			$animate .= ' data-agroup="'.$animation_group.'"';
		}
	}
	else
		$animate = '"';
		
		$animSpeedSet = '#'.$randomId.'.frb_onScreen.frb_animated {-webkit-animation-duration: '.(int)$animation_speed.'ms; animation-duration: '.(int)$animation_speed.'ms;}'.'#'.$randomId.'.frb_onScreen.frb_hinge {-webkit-animation-duration: '.((int)$animation_speed*2).'ms; animation-duration: '.((int)$animation_speed*2).'ms;}';
	$animSpeedSet = (int)$animation_speed != 0 ? $animSpeedSet : '';
	
	
			
	$style = '#'.$randomId.'  {padding-bottom:'.$bot_margin.';}';	


	$html ='';
	$html .= '<style type="text/css">'.$animSpeedSet.$style.'</style><div id="'.$randomId.'" class="frbe_product_grid_container'.$class.$animate.'><div class="frbe_product_grid_wrapper">';
	

	$product_ids = '';
	// $popupData = '';
	$cnt = 0;
	
	global $woocommerce;
	
	$args = array(
		'posts_per_page' => $number_of_posts,
		'post_type' => 'product',
		'order' => $category_order,
		'orderby' => 'title'
	);
	switch ($products_from) {
		case 'category': $metaFilter = NULL; $args['tax_query'] = array(
															array(
																'taxonomy' => 'product_cat',
																'field' => 'term_id',
																'terms' => $categories
															)
														); break;
		case 'featured': $args['meta_key'] = '_featured'; $args['meta_value'] = 'yes'; break;
		case 'sales': $args['meta_query'] = array(
									'relation' => 'OR', 
									array('key' => '_sale_price', 'value' => 0, 'compare' => '>', 'type' => 'numeric'),
							        array('key' => '_min_variation_sale_price', 'value' => 0, 'compare' => '>', 'type' => 'numeric')
    							); break;
	}
	
	$the_query = new WP_Query( $args );
	$i = 0;
	$counter = 0;
	global $fbuilder;
	while ( $the_query->have_posts() ) {
		$the_query->the_post();
		$cat =  wp_get_post_terms(get_the_ID(), 'product_cat');
		$meta = get_post_meta( get_the_ID());
		$currency = get_woocommerce_currency_symbol();	 

		$product = get_product(get_the_ID());
	
		$product_ids .=','.get_the_ID();

		$html.='<div class="frbe_grid_item_wrapper frbe_grid_item_'.$layout[($counter%count($layout))].(($i<$column_number) ? ' frbe_grid_no_top_padding' : '').'"><div class="frbe_grid_item" data-colind="'.$cnt.'" data-product-href="'.get_permalink(get_the_ID()).'">';

		$i++;

		$html.='<div class="frbe_grid_item_inner">'.get_the_post_thumbnail(get_the_ID(),'full');

		$html.='<span class="frbe_product_quickview">+<span><span>'.__('QUICK LOOK','frontend-builder').'</span></span></span>
		<span class="frbe_product_title">'.get_the_title().'</span>
		</div>';

		$counter++;

		$html.='</div></div>';
		$cnt++;	
	}
	wp_reset_postdata();	
	
		$html.='</div></div>';
	
		$product_ids = substr($product_ids, 1);
		$script='<script>
		 			(function($){
		 				$(document).ready(function(){
							if($("#'.$randomId.'").length > 0) {
								$.post(ajaxurl, {action:"frbwoo_quickview_dataset", ids : "'.$product_ids.'"} , function(response) {
									$("#'.$randomId.'").data("product_content", response);
								}, "json");	
								
								$("#'.$randomId.'").frbeProductsGridRefresh();

							}
		 				});
		 				$(window).load(function(){
							if($("#'.$randomId.'").length > 0) {
								$("#'.$randomId.'").frbeProductsGridRefresh();
							}
		 				});
						$( window ).resize(function() {
							$("#'.$randomId.'").frbeProductsGridResize();
						});
						$(document).on("refresh", ".fbuilder_module", function(){
							if($(this).find(".frbe_product_grid_wrapper").length > 0) {
								$(this).find(".frbe_product_grid_wrapper").frbeProductsGridRefresh();
//								$(this).find(".frbe_product_grid_wrapper");
							}
						});
						$(document).on("row_width_change", ".fbuilder_row", function() {
							$(this).find(".frbe_product_grid_wrapper").frbeProductsGridRefresh();
						});
					})(jQuery);
				</script>';	
	$html.=$script;
	return $html;
	
}
add_shortcode( 'frbe_product_grid', 'frbe_product_grid' );





function frbe_products_list( $atts, $content=null ) {	
		global $fbuilderCommerce;
	foreach ($fbuilderCommerce -> productCategoriesQuery as $key => $val) {
		$frbe_product_list_default = $key;
		break;
	}

	extract (shortcode_atts( array(
		'bot_margin' => 24,
		'shortcode_id' => '',
		'class' => '',
		'animate' => 'none',
		'animation_delay' => 0,
		'animation_group' => '',
		'animation_speed' => 1000,
		// 'title_color' => '#27a8e1',
		// 'price_color' => '#808080',
		'per_page' => '1',
		'columns' => '1',
		'products_from' => 'category',
		'category' => $frbe_product_list_default,
		'skus' => '',
		// 'image_format' => '1:1',
		// 'padding' => '3',
		'orderby' => 'title',
		'order' => 'asc',
		// 'item_align' => 'center'
	), $atts));

	global $woocommerce;
	$cart_url = $woocommerce->cart->get_cart_url();
	
	$bot_margin = (int)$bot_margin.'px';
	$randomId = $shortcode_id == '' ? 'frbe_products_list_'.rand() : $shortcode_id;
	$per_page = (int)$per_page;
	$columns = (int)$columns;
	// $padding = (int)$padding;
	// $item_align = in_array($item_align, array('center', 'left', 'right'), true) ? $item_align : 'center';
	
	if($animate != 'none') {
		$animate = ' frb_animated frb_'.$animate.'"';
		if($animation_delay != 0) {
			$animation_delay = (int)$animation_delay;
			$animate .= ' data-adelay="'.$animation_delay.'"';
		}
		if($animation_group != '') {
			$animate .= ' data-agroup="'.$animation_group.'"';
		}
	}
	else
		$animate = '"';
		$animSpeedSet = '<style>'.
							'#'.$randomId.'.frb_onScreen.frb_animated {-webkit-animation-duration: '.(int)$animation_speed.'ms; animation-duration: '.(int)$animation_speed.'ms;}'.
							'#'.$randomId.'.frb_onScreen.frb_hinge {-webkit-animation-duration: '.((int)$animation_speed*2).'ms; animation-duration: '.((int)$animation_speed*2).'ms;}'.
					'</style>';
	$animSpeedSet = (int)$animation_speed != 0 ? $animSpeedSet : '';
	
	
			
	// $html = '<div class="frbe_products_list'.$class.$animate.' id="'.$randomId.'" data-frbe_aspect_ratio="'.$image_format.'" data-frbe_cart_url="'.$cart_url.'" data-frbe_columns="'.$columns.'" >';		
	$html = '<div class="frbe_products_list'.$class.$animate.' id="'.$randomId.'" data-frbe_aspect_ratio="" data-frbe_cart_url="'.$cart_url.'" data-frbe_columns="'.$columns.'" >';
/*
	$html.= '<style> 
		#'.$randomId.'.frbe_products_list ul li {text-align:'.$item_align.'; float:left; width:'.(100/$columns).'%; margin:0px; padding-right:'.$padding.'px; padding-bottom:'.$padding.'px;}
		#'.$randomId.'.frbe_products_list ul li h3 {display:block; width:100%; margin:10px 0 5px 0; padding:0; text-align:'.$item_align.'; color:'.$title_color.';}
		#'.$randomId.'.frbe_products_list ul li span.price  {display:block; width:100%; margin:0 0 10px 0; padding:0; text-align:'.$item_align.'; color:'.$price_color.';}
		#'.$randomId.'.frbe_products_list ul li span.price del {color:'.$price_color.';}
	</style>';*/


	$woo_args = 'per_page="'.$per_page.'" columns="'.$columns.'" orderby="'.$orderby.'" order="'.$order.'"';
	
	switch ($products_from) {
			case 'sale': $html .= do_shortcode('[sale_products '.$woo_args.' ]'); break;
			case 'best_selling': $html .= do_shortcode('[best_selling_products '.$woo_args.' ]'); break;
			case 'top_rated': $html .= do_shortcode('[top_rated_products '.$woo_args.' ]'); break;
			case 'recent': $html .= do_shortcode('[recent_products '.$woo_args.' ]'); break;
			case 'featured': $html .= do_shortcode('[featured_products '.$woo_args.' ]'); break;
			case 'category': $html .= do_shortcode('[product_category category="'.$fbuilderCommerce -> productCategorySlugbyID[$category].'" '.$woo_args.' ]'); break;
			case 'sku': $html .= do_shortcode('[products skus="'.$skus.'" '.$woo_args.' ]'); break;
	}
	/*
	$script='<script>
				(function($){
					$(document).ready(function(){
						if($(this).find(".frbe_products_list").length > 0) {
							$("#'.$randomId.'.frbe_products_list").frbeProductListRefresh();
						}
					});
					$(document).on("refresh", ".fbuilder_module", function(){
						if($(this).find(".frbe_products_list").length > 0) {
							$("#'.$randomId.'.frbe_products_list").frbeProductListRefresh();
						}
					});
					var frbe_product_list_resize;
					$(window).resize(function(){
						clearTimeout(frbe_product_list_resize);
						frbe_product_list_resize = setTimeout(function(){
							$("#'.$randomId.'.frbe_products_list").frbeProductListResize();
						},200);
					});
					$(document).on("row_width_change", ".fbuilder_row", function() {
						clearTimeout(frbe_product_list_resize);
						frbe_product_list_resize = setTimeout(function(){
							$("#'.$randomId.'.frbe_products_list").frbeProductListResize();
						},200);
					});
				})(jQuery);
			</script>';	*/
	$html .= '<div class="frb_clear"></div></div>'/*.$script*/;
	return $html;
}
add_shortcode( 'frbe_products_list', 'frbe_products_list' );



function frbe_product_categories( $atts, $content=null ) {
	
	global $fbuilderCommerce;
	foreach ($fbuilderCommerce -> productCategoriesQuery as $key => $val) {
		$frbe_product_categories_default = $key;
		break;
	}
	
	extract (shortcode_atts( array(
		'bot_margin' => 24,
		'shortcode_id' => '',
		'class' => '',
		'animate' => 'none',
		'animation_delay' => 0,
		'animation_group' => '',
		'animation_speed' => 1000,
		'item_align' => 'center',
		'order_by' => 'name', // name, ID
		'categories' => $frbe_product_categories_default,
		'category_order' => 'ASC',
		'number_of_cat' => 2,
		'number_of_columns' => 2,
		'hide_empty' => 'true',
		'custom_categories' => 'false',
		'only_main' => 'false'
	), $atts));
	
	$bot_margin = (int)$bot_margin.'px';
	$randomId = $shortcode_id == '' ? 'frbe_product_categories_'.rand() : $shortcode_id;
	$number_of_cat = (int)$number_of_cat;
	$only_main = $only_main != 'false' ? true : false;
	$hide_empty = $hide_empty != 'false' ? 1 : 0;
	$custom_categories = $custom_categories != 'false' ? true : false;
	$number_of_columns = (int)$number_of_columns;
	
	$item_align = in_array($item_align, array('center', 'left', 'right'), true) ? $item_align : 'center';
	$category_order = in_array($category_order, array('ASC', 'DESC'), true) ? $category_order : 'ASC';
	$order_by = in_array($order_by, array('name', 'ID'), true) ? $order_by : 'name';
	
	
	
	if($animate != 'none') {
		$animate = ' frb_animated frb_'.$animate.'"';
		
		if($animation_delay != 0) {
			$animation_delay = (int)$animation_delay;
			$animate .= ' data-adelay="'.$animation_delay.'"';
		}
		if($animation_group != '') {
			$animate .= ' data-agroup="'.$animation_group.'"';
		}
	}
	else
		$animate = '"';
		
		$animSpeedSet = '#'.$randomId.'.frb_onScreen.frb_animated {-webkit-animation-duration: '.(int)$animation_speed.'ms; animation-duration: '.(int)$animation_speed.'ms;}'.'#'.$randomId.'.frb_onScreen.frb_hinge {-webkit-animation-duration: '.((int)$animation_speed*2).'ms; animation-duration: '.((int)$animation_speed*2).'ms;}';
	$animSpeedSet = (int)$animation_speed != 0 ? $animSpeedSet : '';
	

	$style = '.frbe_product_categories h3 {text-align:'.$item_align.';}';
	

	$catIDlist = '';
	$customCatItems = explode(',',$categories);
	foreach($customCatItems as $item){
		$catIDlist .= $item.',';
		
	}
	if(substr($catIDlist, -1) === ',') {
		$catIDlist = substr($catIDlist, 0, -1);
	}


	$settings =  ' number="'.(!$custom_categories ? $number_of_cat : '').'"'
				.' orderby="'.$order_by.'"'
				.' order="'.$category_order.'"'
				.' columns="'.$number_of_columns.'"'
				.' hide_empty="'.$hide_empty.'"'
				.' parent="'.($only_main ? '0' : '').'"'
				.' ids="'.($custom_categories ? $catIDlist : '').'"';

	$html = '<style type="text/css">'.$style.$animSpeedSet.'</style><div id="'.$randomId.'" class="frbe_product_categories'.$class.$animate.'>';
	$html .= do_shortcode('[product_categories'.$settings.']');
	$html .= '</div>';


	return $html;
}
add_shortcode( 'frbe_product_categories', 'frbe_product_categories' );


?>