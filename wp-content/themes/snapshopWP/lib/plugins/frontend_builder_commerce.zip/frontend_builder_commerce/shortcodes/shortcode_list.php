<?php


/* Gather wordpress menus */

$nav_menus = get_terms( 'nav_menu', array( 'hide_empty' => true ));
$fbuilder_menus = array();
$fbuilder_menu_std = '';
if(is_array($nav_menus)) 
	foreach($nav_menus as $menu) {
		if($fbuilder_menu_std == '') $fbuilder_menu_std = $menu->slug;
		$fbuilder_menus[$menu->slug] = $menu->name; 
	}

/* Gather wordpress sidebars (Must be done from the wp_head)

$fbuilder_sidebars = array();
$fbuilder_sidebar_std = '';
foreach ( $GLOBALS['wp_registered_sidebars'] as $sidebar ) {
	if($fbuilder_sidebar_std == '') $fbuilder_sidebar_std = $sidebar['id'];
	$fbuilder_sidebars[$sidebar['id']] = ucwords( $sidebar['name'] );
} 
*/

/* Gather wordpress posts */

global $wpdb, $fbuilder;

 $querystr = "
    SELECT $wpdb->posts.ID, $wpdb->posts.post_title
    FROM $wpdb->posts
	WHERE $wpdb->posts.post_status = 'publish'
	AND $wpdb->posts.post_type = 'post'
    ORDER BY $wpdb->posts.post_date DESC
 ";
$posts_array = $wpdb->get_results($querystr, OBJECT);

$fbuilder_wp_posts = array();
$first_post = '';
foreach($posts_array as $key => $obj) {
	if($first_post == '') $first_post = $key;
	$fbuilder_wp_posts[$obj->ID] = $obj->post_title;
}
$admin_optionsDB = $fbuilder->option();
$opts = array();
foreach($admin_optionsDB as $opt) {
	if(isset($opt->name) && isset($opt->value))
		$opts[$opt->name] = $opt->value;
}

$animationList = array(
	'none' => __('None', 'frontend-builder'),
	'flipInX' => __('Flip in X', 'frontend-builder'),
	'flipInY' => __('Flip in Y', 'frontend-builder'),
	'fadeIn' => __('Fade in', 'frontend-builder'),
	'fadeInDown' => __('Fade in from top', 'frontend-builder'),
	'fadeInUp' => __('Fade in from bottom', 'frontend-builder'),
	'fadeInLeft' => __('Fade in from left', 'frontend-builder'),
	'fadeInRight' => __('Fade in from right', 'frontend-builder'),
	'fadeInDownBig' => __('Slide in from top', 'frontend-builder'),
	'fadeInUpBig' => __('Slide in from bottom', 'frontend-builder'),
	'fadeInLeftBig' => __('Slide in from left', 'frontend-builder'),
	'fadeInRightBig' => __('Slide in from right', 'frontend-builder'),
	'bounceIn' => __('Bounce in', 'frontend-builder'),
	'bounceInDown' => __('Bounce in from top', 'frontend-builder'),
	'bounceInUp' => __('Bounce in from bottom', 'frontend-builder'),
	'bounceInLeft' => __('Bounce in from left', 'frontend-builder'),
	'bounceInRight' => __('Bounce in from right', 'frontend-builder'),
	'rotateIn' => __('Rotate in', 'frontend-builder'),
	'rotateInDownLeft' => __('Rotate in from top-left', 'frontend-builder'),
	'rotateInDownRight' => __('Rotate in from top-right', 'frontend-builder'),
	'rotateInUpLeft' => __('Rotate in from bottom-left', 'frontend-builder'),
	'rotateInUpRight' => __('Rotate in from bottom-right', 'frontend-builder'),
	'lightSpeedIn' => __('Lightning speed', 'frontend-builder'),
	'rollIn' => __('Roll in', 'frontend-builder')
);

$animationControl = array(
	'group_animate' => array(
		'type' => 'collapsible',
		'label' => __('Animation','frontend-builder'),
		'options' => array(
			'animate' => array(
				'type' => 'select',
				'label' => __('Type:','frontend-builder'),
				'std' => 'none',
				'label_width' => 0.25,
				'control_width' => 0.75,
				'options' => $animationList
			),
			'animation_delay' => array(
				'type' => 'number',
				'label' => __('Delay:','frontend-builder'),
				'std' => 0,
				'unit' => 'ms',
				'min' => 0,
				'step' => 50,
				'max' => 10000,
				'half_column' => 'true'
			),
			'animation_speed' => array(
				'type' => 'number',
				'label' => __('Speed:','frontend-builder'),
				'std' => 1000,
				'unit' => 'ms',
				'min' => 100,
				'step' => 50,
				'max' => 3000,
				'half_column' => 'true'
			),
			'animation_group' => array(
				'type' => 'input',
				'label_width' => 0.25,
				'control_width' => 0.75,
				'label' => __('Group:','frontend-builder'),
				'std' => '',
			)
		)
	)
);



if(isset($opts['css_classes']) && $opts['css_classes'] == 'true') {
	$classControl = array(
		'group_css' => array(
			'type' => 'collapsible',
			'label' => __('ID & Custom CSS','frontend-builder'),
			'options' => array(
				'shortcode_id' => array(
					'type' => 'input',
					'label' => __('ID:','frontend-builder'),
					'desc' => __('For linking via hashtags','frontend-builder'),
					'label_width' => 0.25,
					'control_width' => 0.75,
					'std' => ''
				),
				'class' => array(
					'type' => 'input',
					'label' => __('Class:','frontend-builder'),
					'desc' => __('For custom css','frontend-builder'),
					'label_width' => 0.25,
					'control_width' => 0.75,
					'std' => ''
				)
			)
		)
	);
	$tabsId = array(
		'custom_id' => array(
			'type' => 'input',
			'label' => __('Tab ID:','frontend-builder'),
			'desc' => __('For use of anchor in url. Make sure that this ID is unique on the page.','frontend-builder'),
			'label_width' => 0.25,
			'std' => ''
		)
	);
}
else {
	$classControl = array();
	$tabsId = array();
}

/* -------------------------------------------------------------------------------- */
/* fbuilder_woo_ext_product_slider */
/* -------------------------------------------------------------------------------- */


	global $fbuilderCommerce;
	$frbe_product_slider_default='';
	foreach ($fbuilderCommerce -> productCategoriesQuery as $key => $val) {
		$frbe_product_slider_default = $key;
		break;
	}


$frbe_product_slider = array(

	'frbe_product_slider' => array(
		'type' => 'draggable',
		'text' => __('Product Slider','frontend-builder'),
		'icon' => $this->url.'images/product-slider.png',
		'function' => 'frbe_product_slider',
		'group' => 'woo_extension',
		'options' => array_merge(
		 array(
			'group_basic' => array(
				'type' => 'collapsible',
				'label' => __('Basic','frontend-builder'),
				'open' => 'true',
				'options' => array(
					'slides_per_view' => array(
						'type' => 'number',
						'label' => __('Slides Per View:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'min' => 1,
						'max' => 15,
						'unit' => '',
						'std' => 3
					),
					'number_of_posts' => array(
						'type' => 'number',
						'label' => __('Number Of Posts:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'min' => 1,
						'max' => 50,
						'unit' => '',
						'std' => 5
					),
					'products_from' => array(
						'type' => 'select',
						'label' => __('Products From:','frontend-builder'),
						'std' => 'category',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'category' => 'Category',
							'featured' => 'Featured',
							'sales' => 'Sales'
						)
					),
					'categories' => array(
						'type' => 'select',
						'label' => __('Categories:','frontend-builder'),
						'std' => $frbe_product_slider_default,
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => $fbuilderCommerce -> productCategoriesQuery,
						'hide_if' => array (
							'products_from' => array('featured', 'sales')
						)
					),
					'category_order' => array(
						'type' => 'select',
						'label' => __('Order:','frontend-builder'),
						'std' => 'desc',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'desc' => 'Descending',
							'asc' => 'Ascending'
						)
					),
					'aspect_ratio' => array(
						'type' => 'select',
						'label' => __('Image Format:','frontend-builder'),
						'std' => '1:1',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'1:1.5' => 'Portrait',
							'1:1' => 'Square',
							'16:9' => 'Landscape'
						)
					),
					'resize_reference' => array(
						'type' => 'number',
						'label' => __('Min. Slide Width:','frontend-builder'),
						'desc' => __('Reference for responsive layout calculations', 'frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'unit' => 'px',
						'std' => 200
					),
					'item_align' => array(
						'type' => 'select',
						'label' => __('Item Align:','frontend-builder'),
						'std' => 'center',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'center' => 'Center',
							'left' => 'Left',
							'right' => 'Right'
						)
					),
					'item_spacing' => array(
						'type' => 'number',
						'label' => __('Item Padding:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'unit' => 'px',
						'std' => 20
					)
				)
			),	
			'group_text' => array(
				'type' => 'collapsible',
				'label' => __('Text','frontend-builder'),
				'open' => 'true',
				'options' => array(
					'title_color' => array(
						'type' => 'color',
						'label' => __('Title:','frontend-builder'),
						'std' => $opts['main_color'],
						'label_width' => 0.5,
						'control_width' => 0.5
					),
					'price_color' => array(
						'type' => 'color',
						'label' => __('Price:','frontend-builder'),
						'std' => '#111111',
						'label_width' => 0.5,
						'control_width' => 0.5
					),
					'category_color' => array(
						'type' => 'color',
						'label' => __('Category:','frontend-builder'),
						'std' => '#111111',
						'label_width' => 0.5,
						'control_width' => 0.5
					),
					'category_show' => array(
						'type' => 'checkbox',
						'half_column' => 'true',
						'std' => 'true',
						'label' => __('Category','frontend-builder')
					)
				)
			)
		),
		$classControl,
		array(
			'group_general' => array(
				'type' => 'collapsible',
				'label' => __('General','frontend-builder'),
				'options' => array(
					'bot_margin' => array(
						'type' => 'number',
						'label' => __('Bottom margin:','frontend-builder'),
						'std' => $opts['bottom_margin'],
						'unit' => 'px'
					)
				)
			)
		),
		$animationControl
		)
	)
);


/* -------------------------------------------------------------------------------- */
/* fbuilder_woo_ext_product_grid */
/* -------------------------------------------------------------------------------- */


$frbe_product_grid = array(

	'frbe_product_grid' => array(
		'type' => 'draggable',
		'text' => __('Product Grid','frontend-builder'),
		'icon' => $this->url.'images/product-grid.png',
		'function' => 'frbe_product_grid',
		'group' => 'woo_extension',
		'options' => array_merge(
		 array(
			'group_basic' => array(
				'type' => 'collapsible',
				'label' => __('Basic','frontend-builder'),
				'open' => 'true',
				'options' => array(
					'number_of_posts' => array(
						'type' => 'number',
						'label' => __('Number Of Posts:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'min' => 1,
						'max' => 50,
						'unit' => '',
						'std' => 5
					),
					'products_from' => array(
						'type' => 'select',
						'label' => __('Products From:','frontend-builder'),
						'std' => 'category',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'category' => __('Category','frontend-builder'),
							'featured' => __('Featured','frontend-builder'),
							'sales' => __('Sales','frontend-builder')
						)
					),
					'categories' => array(
						'type' => 'select',
						'multiselect' => 'true',
						'label' => __('Categories:','frontend-builder'),
						'std' => $frbe_product_slider_default.'',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => $fbuilderCommerce -> productCategoriesQuery,
						'hide_if' => array (
							'products_from' => array('featured', 'sales')
						)
					),
					'category_order' => array(
						'type' => 'select',
						'label' => __('Order:','frontend-builder'),
						'std' => 'desc',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'desc' => 'Descending',
							'asc' => 'Ascending'
						)
					)
				)
			)
		),
		$classControl,
		array(
			'group_general' => array(
				'type' => 'collapsible',
				'label' => __('General','frontend-builder'),
				'options' => array(
					'bot_margin' => array(
						'type' => 'number',
						'label' => __('Bottom margin:','frontend-builder'),
						'std' => $opts['bottom_margin'],
						'unit' => 'px'
					)
				)
			)
		),
		$animationControl
		)
	)
);


/* -------------------------------------------------------------------------------- */
/* fbuilder_woo_ext_product_list */
/* -------------------------------------------------------------------------------- */


$frbe_products_list = array(

	'frbe_products_list' => array(
		'type' => 'draggable',
		'text' => __('Products','frontend-builder'),
		'icon' => $this->url.'images/products.png',
		'function' => 'frbe_products_list',
		'group' => 'woo_extension',
		'options' => array_merge(
		 array(
			'group_filter' => array(
				'type' => 'collapsible',
				'label' => __('Filter','frontend-builder'),
				'open' => 'true',
				'options' => array(
					'per_page' => array(
						'type' => 'number',
						'label' => __('Number of Items:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'min' => 1,
						'max' => 20,
						'unit' => '',
						'std' => 1
					),
					'columns' => array(
						'type' => 'number',
						'label' => __('Number of Columns:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'min' => 1,
						'max' => 4,
						'unit' => '',
						'std' => 3
					),
					'products_from' => array(
						'type' => 'select',
						'label' => __('Products from:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'std' => 'category',
						'options' => array(
							'sale' => __('Sale','frontend-builder'),
							'best_selling' => __('Best Selling','frontend-builder'),
							'top_rated' => __('Top Rated','frontend-builder'),
							'recent' => __('Recent','frontend-builder'),
							'featured' => __('Featured','frontend-builder'),
							'category' => __('Category','frontend-builder'),
							'sku' => __('SKU','frontend-builder'),
							// 'attribute' => __('Attribute','frontend-builder'),
						)
					),
					'category' => array(
						'type' => 'select',
						'label' => __('Category:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'std' => $frbe_product_slider_default.'',
						'options' => $fbuilderCommerce -> productCategoriesQuery,
						'hide_if' => array(
							'products_from' => array('sale','best_selling','top_rated','recent','featured','sku','attribute')
						)
					),
					'skus' => array(
						'type' => 'input',
						'label' => __('SKUs:','frontend-builder'),
						'desc' => __('Insert SKU list here. Items are separated with a comma - "," ','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'std' => '',
						'hide_if' => array(
							'products_from' => array('sale','best_selling','top_rated','recent','featured','category','attribute')
						)
					),
					'orderby' => array(
						'type' => 'select',
						'label' => __('Order by:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'std' => 'title',
						'options' => array(
							'title' => __('Title','frontend-builder'),
							'date' => __('Date','frontend-builder'),
							'name' => __('Name','frontend-builder'),
							'rand' => __('Random','frontend-builder')
						)
					),
					'order' => array(
						'type' => 'select',
						'label' => __('Order:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'std' =>'asc',
						'options' => array(
							'asc' => 'Ascending',
							'desc' => 'Descending'
						)
					)
					/*,
					'image_format' => array(
						'type' => 'select',
						'label' => __('Image Format:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'std' =>'1:1',
						'options' => array(
							'1:1.5' => __('Portrait','frontend-builder'),
							'1:1' => __('Square','frontend-builder'),
							'16:9' => __('Landscape','frontend-builder')
						)
					),
					'item_align' => array(
						'type' => 'select',
						'label' => __('Item Align:','frontend-builder'),
						'std' => 'center',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'center' => 'Center',
							'left' => 'Left',
							'right' => 'Right'
						)
					),
					'padding' => array(
						'type' => 'number',
						'label' => __('Column padding:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'min' => 1,
						'max' => 100,
						'unit' => 'px',
						'std' => 3
					)*/
				)
			)
/*,
			'group_text' => array(
				'type' => 'collapsible',
				'label' => __('Text','frontend-builder'),
				'open' => 'true',
				'options' => array(
					'title_color' => array(
						'type' => 'color',
						'label' => __('Title:','frontend-builder'),
						'std' => $opts['main_color'],
						'label_width' => 0.5,
						'control_width' => 0.5
					),
					'price_color' => array(
						'type' => 'color',
						'label' => __('Price:','frontend-builder'),
						'std' => $opts['text_color'],
						'label_width' => 0.5,
						'control_width' => 0.5
					)
				)
			)*/
		),
		$classControl,
		array(
			'group_general' => array(
				'type' => 'collapsible',
				'label' => __('General','frontend-builder'),
				'options' => array(
					'bot_margin' => array(
						'type' => 'number',
						'label' => __('Bottom margin:','frontend-builder'),
						'std' => $opts['bottom_margin'],
						'unit' => 'px'
					)
				)
			)
		),
		$animationControl
		)
	)
);


/* -------------------------------------------------------------------------------- */
/* fbuilder_woo_ext_product_categories */
/* -------------------------------------------------------------------------------- */


$frbe_product_categories = array(

	'frbe_product_categories' => array(
		'type' => 'draggable',
		'text' => __('Product Categories','frontend-builder'),
		'icon' => $this->url.'images/product-categories.png',
		'function' => 'frbe_product_categories',
		'group' => 'woo_extension',
		'options' => array_merge(
		 array(
			'group_basic' => array(
				'type' => 'collapsible',
				'label' => __('Basic','frontend-builder'),
				'open' => 'true',
				'options' => array(
					'number_of_columns' => array(
						'type' => 'number',
						'label' => __('No. of columns:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'min' => 1,
						'max' => 6,
						'unit' => '',
						'std' => 2
					),
					'number_of_cat' => array(
						'type' => 'number',
						'label' => __('No. of items:','frontend-builder'),
						'label_width' => 0.5,
						'control_width' => 0.5,
						'min' => 1,
						'max' => 100,
						'unit' => '',
						'std' => 2,
						'hide_if' => array (
							'custom_categories' => array('true')
						)
					),
					'categories' => array(
						'type' => 'select',
						'label' => __('Categories:','frontend-builder'),
						'multiselect' => 'true',
						'std' => $frbe_product_slider_default.'',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => $fbuilderCommerce -> productCategoriesQuery,
						'hide_if' => array (
							'custom_categories' => array('false')
						)
					),
					'category_order' => array(
						'type' => 'select',
						'label' => __('Order:','frontend-builder'),
						'std' => 'ASC',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'DESC' => 'Descending',
							'ASC' => 'Ascending'
						)
					),
					'order_by' => array(
						'type' => 'select',
						'label' => __('Order By:','frontend-builder'),
						'std' => 'name',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'name' => 'Name',
							'ID' => 'ID',
						)
					),
					'item_align' => array(
						'type' => 'select',
						'label' => __('Item Align:','frontend-builder'),
						'std' => 'center',
						'label_width' => 0.5,
						'control_width' => 0.5,
						'options' => array(
							'center' => 'Center',
							'left' => 'Left',
							'right' => 'Right'
						)
					),
					'custom_categories' => array(
						'type' => 'checkbox',
						'half_column' => 'true',
						'std' => 'false',
						'label' => __('Custom items','frontend-builder')
					),
					'hide_empty' => array(
						'type' => 'checkbox',
						'half_column' => 'true',
						'std' => 'true',
						'label' => __('Hide empty','frontend-builder')
					),
					'only_main' => array(
						'type' => 'checkbox',
						'std' => 'false',
						'label' => __('Only main categories','frontend-builder')
					)
				)
			)
		),
		$classControl,
		array(
			'group_general' => array(
				'type' => 'collapsible',
				'label' => __('General','frontend-builder'),
				'options' => array(
					'bot_margin' => array(
						'type' => 'number',
						'label' => __('Bottom margin:','frontend-builder'),
						'std' => $opts['bottom_margin'],
						'unit' => 'px'
					)
				)
			)
		),
		$animationControl
		)
	)
);






$fbuilder_shortcodes = array_merge($frbe_product_slider, $frbe_products_list, $frbe_product_grid, $frbe_product_categories);


$output = $fbuilder_shortcodes;
?>